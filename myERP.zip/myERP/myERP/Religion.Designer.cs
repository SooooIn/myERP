﻿namespace myERP
{
    partial class Religion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.r_tabMenu = new System.Windows.Forms.TabControl();
            this.r_Search = new System.Windows.Forms.TabPage();
            this.lvReligion_s = new System.Windows.Forms.ListView();
            this.lvReligion_s_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvReligion_s_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_r_search = new System.Windows.Forms.Button();
            this.s_religion = new System.Windows.Forms.TextBox();
            this.lbl_s_religion = new System.Windows.Forms.Label();
            this.r_Add = new System.Windows.Forms.TabPage();
            this.lvReligion_a = new System.Windows.Forms.ListView();
            this.lvReligion_a_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvReligion_a_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_r_add = new System.Windows.Forms.Button();
            this.a_r_code = new System.Windows.Forms.TextBox();
            this.a_religion = new System.Windows.Forms.TextBox();
            this.lbl_a_r_code = new System.Windows.Forms.Label();
            this.lbl_a_religion = new System.Windows.Forms.Label();
            this.r_Update = new System.Windows.Forms.TabPage();
            this.ur_hidden2 = new System.Windows.Forms.TextBox();
            this.ur_hidden = new System.Windows.Forms.TextBox();
            this.lvReligion_u = new System.Windows.Forms.ListView();
            this.lvReligion_u_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvReligion_u_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_r_update = new System.Windows.Forms.Button();
            this.u_r_code = new System.Windows.Forms.TextBox();
            this.u_religion = new System.Windows.Forms.TextBox();
            this.lbl_u_r_code = new System.Windows.Forms.Label();
            this.lbl_u_religion = new System.Windows.Forms.Label();
            this.r_Delete = new System.Windows.Forms.TabPage();
            this.dr_hidden = new System.Windows.Forms.TextBox();
            this.btn_r_delete = new System.Windows.Forms.Button();
            this.lvReligion_d = new System.Windows.Forms.ListView();
            this.lvReligion_d_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvReligion_d_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dr_hidden2 = new System.Windows.Forms.TextBox();
            this.r_tabMenu.SuspendLayout();
            this.r_Search.SuspendLayout();
            this.r_Add.SuspendLayout();
            this.r_Update.SuspendLayout();
            this.r_Delete.SuspendLayout();
            this.SuspendLayout();
            // 
            // r_tabMenu
            // 
            this.r_tabMenu.Controls.Add(this.r_Search);
            this.r_tabMenu.Controls.Add(this.r_Add);
            this.r_tabMenu.Controls.Add(this.r_Update);
            this.r_tabMenu.Controls.Add(this.r_Delete);
            this.r_tabMenu.Location = new System.Drawing.Point(0, 0);
            this.r_tabMenu.Name = "r_tabMenu";
            this.r_tabMenu.SelectedIndex = 0;
            this.r_tabMenu.Size = new System.Drawing.Size(386, 363);
            this.r_tabMenu.TabIndex = 0;
            this.r_tabMenu.SelectedIndexChanged += new System.EventHandler(this.r_tabMenu_SelectedIndexChanged);
            // 
            // r_Search
            // 
            this.r_Search.Controls.Add(this.lvReligion_s);
            this.r_Search.Controls.Add(this.btn_r_search);
            this.r_Search.Controls.Add(this.s_religion);
            this.r_Search.Controls.Add(this.lbl_s_religion);
            this.r_Search.Location = new System.Drawing.Point(4, 25);
            this.r_Search.Name = "r_Search";
            this.r_Search.Padding = new System.Windows.Forms.Padding(3);
            this.r_Search.Size = new System.Drawing.Size(378, 334);
            this.r_Search.TabIndex = 0;
            this.r_Search.Text = "조회";
            this.r_Search.UseVisualStyleBackColor = true;
            // 
            // lvReligion_s
            // 
            this.lvReligion_s.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvReligion_s_k,
            this.lvReligion_s_c});
            this.lvReligion_s.GridLines = true;
            this.lvReligion_s.Location = new System.Drawing.Point(30, 90);
            this.lvReligion_s.Name = "lvReligion_s";
            this.lvReligion_s.Size = new System.Drawing.Size(300, 200);
            this.lvReligion_s.TabIndex = 7;
            this.lvReligion_s.UseCompatibleStateImageBehavior = false;
            this.lvReligion_s.View = System.Windows.Forms.View.Details;
            // 
            // lvReligion_s_k
            // 
            this.lvReligion_s_k.Text = "종교";
            // 
            // lvReligion_s_c
            // 
            this.lvReligion_s_c.Text = "코드";
            // 
            // btn_r_search
            // 
            this.btn_r_search.Location = new System.Drawing.Point(230, 25);
            this.btn_r_search.Name = "btn_r_search";
            this.btn_r_search.Size = new System.Drawing.Size(60, 26);
            this.btn_r_search.TabIndex = 6;
            this.btn_r_search.Text = "찾기";
            this.btn_r_search.UseVisualStyleBackColor = true;
            this.btn_r_search.Click += new System.EventHandler(this.btn_r_search_Click);
            // 
            // s_religion
            // 
            this.s_religion.Location = new System.Drawing.Point(100, 25);
            this.s_religion.Name = "s_religion";
            this.s_religion.Size = new System.Drawing.Size(100, 25);
            this.s_religion.TabIndex = 5;
            // 
            // lbl_s_religion
            // 
            this.lbl_s_religion.AutoSize = true;
            this.lbl_s_religion.Location = new System.Drawing.Point(27, 30);
            this.lbl_s_religion.Name = "lbl_s_religion";
            this.lbl_s_religion.Size = new System.Drawing.Size(37, 15);
            this.lbl_s_religion.TabIndex = 4;
            this.lbl_s_religion.Text = "종교";
            // 
            // r_Add
            // 
            this.r_Add.Controls.Add(this.lvReligion_a);
            this.r_Add.Controls.Add(this.btn_r_add);
            this.r_Add.Controls.Add(this.a_r_code);
            this.r_Add.Controls.Add(this.a_religion);
            this.r_Add.Controls.Add(this.lbl_a_r_code);
            this.r_Add.Controls.Add(this.lbl_a_religion);
            this.r_Add.Location = new System.Drawing.Point(4, 25);
            this.r_Add.Name = "r_Add";
            this.r_Add.Padding = new System.Windows.Forms.Padding(3);
            this.r_Add.Size = new System.Drawing.Size(378, 334);
            this.r_Add.TabIndex = 1;
            this.r_Add.Text = "등록";
            this.r_Add.UseVisualStyleBackColor = true;
            // 
            // lvReligion_a
            // 
            this.lvReligion_a.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvReligion_a_k,
            this.lvReligion_a_c});
            this.lvReligion_a.GridLines = true;
            this.lvReligion_a.Location = new System.Drawing.Point(30, 90);
            this.lvReligion_a.Name = "lvReligion_a";
            this.lvReligion_a.Size = new System.Drawing.Size(300, 200);
            this.lvReligion_a.TabIndex = 5;
            this.lvReligion_a.UseCompatibleStateImageBehavior = false;
            this.lvReligion_a.View = System.Windows.Forms.View.Details;
            // 
            // lvReligion_a_k
            // 
            this.lvReligion_a_k.Text = "종교";
            // 
            // lvReligion_a_c
            // 
            this.lvReligion_a_c.Text = "코드";
            // 
            // btn_r_add
            // 
            this.btn_r_add.Location = new System.Drawing.Point(255, 35);
            this.btn_r_add.Name = "btn_r_add";
            this.btn_r_add.Size = new System.Drawing.Size(75, 30);
            this.btn_r_add.TabIndex = 4;
            this.btn_r_add.Text = "추가하기";
            this.btn_r_add.UseVisualStyleBackColor = true;
            this.btn_r_add.Click += new System.EventHandler(this.btn_r_add_Click);
            // 
            // a_r_code
            // 
            this.a_r_code.Location = new System.Drawing.Point(100, 50);
            this.a_r_code.Name = "a_r_code";
            this.a_r_code.Size = new System.Drawing.Size(140, 25);
            this.a_r_code.TabIndex = 3;
            // 
            // a_religion
            // 
            this.a_religion.Location = new System.Drawing.Point(100, 15);
            this.a_religion.Name = "a_religion";
            this.a_religion.Size = new System.Drawing.Size(140, 25);
            this.a_religion.TabIndex = 2;
            // 
            // lbl_a_r_code
            // 
            this.lbl_a_r_code.AutoSize = true;
            this.lbl_a_r_code.Location = new System.Drawing.Point(36, 50);
            this.lbl_a_r_code.Name = "lbl_a_r_code";
            this.lbl_a_r_code.Size = new System.Drawing.Size(37, 15);
            this.lbl_a_r_code.TabIndex = 1;
            this.lbl_a_r_code.Text = "코드";
            // 
            // lbl_a_religion
            // 
            this.lbl_a_religion.AutoSize = true;
            this.lbl_a_religion.Location = new System.Drawing.Point(36, 20);
            this.lbl_a_religion.Name = "lbl_a_religion";
            this.lbl_a_religion.Size = new System.Drawing.Size(37, 15);
            this.lbl_a_religion.TabIndex = 0;
            this.lbl_a_religion.Text = "종교";
            // 
            // r_Update
            // 
            this.r_Update.Controls.Add(this.ur_hidden2);
            this.r_Update.Controls.Add(this.ur_hidden);
            this.r_Update.Controls.Add(this.lvReligion_u);
            this.r_Update.Controls.Add(this.btn_r_update);
            this.r_Update.Controls.Add(this.u_r_code);
            this.r_Update.Controls.Add(this.u_religion);
            this.r_Update.Controls.Add(this.lbl_u_r_code);
            this.r_Update.Controls.Add(this.lbl_u_religion);
            this.r_Update.Location = new System.Drawing.Point(4, 25);
            this.r_Update.Name = "r_Update";
            this.r_Update.Padding = new System.Windows.Forms.Padding(3);
            this.r_Update.Size = new System.Drawing.Size(378, 334);
            this.r_Update.TabIndex = 2;
            this.r_Update.Text = "수정";
            this.r_Update.UseVisualStyleBackColor = true;
            // 
            // ur_hidden2
            // 
            this.ur_hidden2.Location = new System.Drawing.Point(232, 296);
            this.ur_hidden2.Name = "ur_hidden2";
            this.ur_hidden2.Size = new System.Drawing.Size(100, 25);
            this.ur_hidden2.TabIndex = 8;
            this.ur_hidden2.Visible = false;
            // 
            // ur_hidden
            // 
            this.ur_hidden.Location = new System.Drawing.Point(151, 296);
            this.ur_hidden.Name = "ur_hidden";
            this.ur_hidden.Size = new System.Drawing.Size(75, 25);
            this.ur_hidden.TabIndex = 7;
            this.ur_hidden.Visible = false;
            // 
            // lvReligion_u
            // 
            this.lvReligion_u.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvReligion_u_k,
            this.lvReligion_u_c});
            this.lvReligion_u.GridLines = true;
            this.lvReligion_u.Location = new System.Drawing.Point(30, 90);
            this.lvReligion_u.Name = "lvReligion_u";
            this.lvReligion_u.Size = new System.Drawing.Size(300, 200);
            this.lvReligion_u.TabIndex = 5;
            this.lvReligion_u.UseCompatibleStateImageBehavior = false;
            this.lvReligion_u.View = System.Windows.Forms.View.Details;
            this.lvReligion_u.SelectedIndexChanged += new System.EventHandler(this.lvReligion_u_SelectedIndexChanged);
            // 
            // lvReligion_u_k
            // 
            this.lvReligion_u_k.Text = "종교";
            // 
            // lvReligion_u_c
            // 
            this.lvReligion_u_c.Text = "코드";
            // 
            // btn_r_update
            // 
            this.btn_r_update.Location = new System.Drawing.Point(255, 35);
            this.btn_r_update.Name = "btn_r_update";
            this.btn_r_update.Size = new System.Drawing.Size(75, 30);
            this.btn_r_update.TabIndex = 4;
            this.btn_r_update.Text = "수정하기";
            this.btn_r_update.UseVisualStyleBackColor = true;
            this.btn_r_update.Click += new System.EventHandler(this.btn_r_update_Click);
            // 
            // u_r_code
            // 
            this.u_r_code.Location = new System.Drawing.Point(100, 50);
            this.u_r_code.Name = "u_r_code";
            this.u_r_code.Size = new System.Drawing.Size(140, 25);
            this.u_r_code.TabIndex = 3;
            // 
            // u_religion
            // 
            this.u_religion.Location = new System.Drawing.Point(100, 15);
            this.u_religion.Name = "u_religion";
            this.u_religion.Size = new System.Drawing.Size(140, 25);
            this.u_religion.TabIndex = 2;
            // 
            // lbl_u_r_code
            // 
            this.lbl_u_r_code.AutoSize = true;
            this.lbl_u_r_code.Location = new System.Drawing.Point(36, 50);
            this.lbl_u_r_code.Name = "lbl_u_r_code";
            this.lbl_u_r_code.Size = new System.Drawing.Size(37, 15);
            this.lbl_u_r_code.TabIndex = 1;
            this.lbl_u_r_code.Text = "코드";
            // 
            // lbl_u_religion
            // 
            this.lbl_u_religion.AutoSize = true;
            this.lbl_u_religion.Location = new System.Drawing.Point(36, 20);
            this.lbl_u_religion.Name = "lbl_u_religion";
            this.lbl_u_religion.Size = new System.Drawing.Size(37, 15);
            this.lbl_u_religion.TabIndex = 0;
            this.lbl_u_religion.Text = "종교";
            // 
            // r_Delete
            // 
            this.r_Delete.Controls.Add(this.dr_hidden2);
            this.r_Delete.Controls.Add(this.dr_hidden);
            this.r_Delete.Controls.Add(this.btn_r_delete);
            this.r_Delete.Controls.Add(this.lvReligion_d);
            this.r_Delete.Location = new System.Drawing.Point(4, 25);
            this.r_Delete.Name = "r_Delete";
            this.r_Delete.Padding = new System.Windows.Forms.Padding(3);
            this.r_Delete.Size = new System.Drawing.Size(378, 334);
            this.r_Delete.TabIndex = 3;
            this.r_Delete.Text = "삭제";
            this.r_Delete.UseVisualStyleBackColor = true;
            // 
            // dr_hidden
            // 
            this.dr_hidden.Location = new System.Drawing.Point(39, 291);
            this.dr_hidden.Name = "dr_hidden";
            this.dr_hidden.Size = new System.Drawing.Size(100, 25);
            this.dr_hidden.TabIndex = 2;
            this.dr_hidden.Visible = false;
            // 
            // btn_r_delete
            // 
            this.btn_r_delete.Location = new System.Drawing.Point(294, 291);
            this.btn_r_delete.Name = "btn_r_delete";
            this.btn_r_delete.Size = new System.Drawing.Size(75, 30);
            this.btn_r_delete.TabIndex = 1;
            this.btn_r_delete.Text = "삭제";
            this.btn_r_delete.UseVisualStyleBackColor = true;
            this.btn_r_delete.Click += new System.EventHandler(this.btn_r_delete_Click);
            // 
            // lvReligion_d
            // 
            this.lvReligion_d.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvReligion_d_k,
            this.lvReligion_d_c});
            this.lvReligion_d.GridLines = true;
            this.lvReligion_d.Location = new System.Drawing.Point(8, 6);
            this.lvReligion_d.Name = "lvReligion_d";
            this.lvReligion_d.Size = new System.Drawing.Size(360, 270);
            this.lvReligion_d.TabIndex = 0;
            this.lvReligion_d.UseCompatibleStateImageBehavior = false;
            this.lvReligion_d.View = System.Windows.Forms.View.Details;
            this.lvReligion_d.SelectedIndexChanged += new System.EventHandler(this.lvReligion_d_SelectedIndexChanged);
            // 
            // lvReligion_d_k
            // 
            this.lvReligion_d_k.Text = "종교";
            // 
            // lvReligion_d_c
            // 
            this.lvReligion_d_c.Text = "코드";
            // 
            // dr_hidden2
            // 
            this.dr_hidden2.Location = new System.Drawing.Point(159, 290);
            this.dr_hidden2.Name = "dr_hidden2";
            this.dr_hidden2.Size = new System.Drawing.Size(100, 25);
            this.dr_hidden2.TabIndex = 3;
            this.dr_hidden2.Visible = false;
            // 
            // Religion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 361);
            this.Controls.Add(this.r_tabMenu);
            this.Name = "Religion";
            this.Text = "종교 관리";
            this.r_tabMenu.ResumeLayout(false);
            this.r_Search.ResumeLayout(false);
            this.r_Search.PerformLayout();
            this.r_Add.ResumeLayout(false);
            this.r_Add.PerformLayout();
            this.r_Update.ResumeLayout(false);
            this.r_Update.PerformLayout();
            this.r_Delete.ResumeLayout(false);
            this.r_Delete.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl r_tabMenu;
        private System.Windows.Forms.TabPage r_Search;
        private System.Windows.Forms.TabPage r_Add;
        private System.Windows.Forms.TabPage r_Update;
        private System.Windows.Forms.TabPage r_Delete;
        private System.Windows.Forms.ListView lvReligion_s;
        private System.Windows.Forms.Button btn_r_search;
        private System.Windows.Forms.TextBox s_religion;
        private System.Windows.Forms.Label lbl_s_religion;
        private System.Windows.Forms.ListView lvReligion_a;
        private System.Windows.Forms.Button btn_r_add;
        private System.Windows.Forms.TextBox a_r_code;
        private System.Windows.Forms.TextBox a_religion;
        private System.Windows.Forms.Label lbl_a_r_code;
        private System.Windows.Forms.Label lbl_a_religion;
        private System.Windows.Forms.ListView lvReligion_u;
        private System.Windows.Forms.Button btn_r_update;
        private System.Windows.Forms.TextBox u_r_code;
        private System.Windows.Forms.TextBox u_religion;
        private System.Windows.Forms.Label lbl_u_r_code;
        private System.Windows.Forms.Label lbl_u_religion;
        private System.Windows.Forms.Button btn_r_delete;
        private System.Windows.Forms.ListView lvReligion_d;
        private System.Windows.Forms.ColumnHeader lvReligion_s_k;
        private System.Windows.Forms.ColumnHeader lvReligion_s_c;
        private System.Windows.Forms.ColumnHeader lvReligion_a_k;
        private System.Windows.Forms.ColumnHeader lvReligion_a_c;
        private System.Windows.Forms.ColumnHeader lvReligion_u_k;
        private System.Windows.Forms.ColumnHeader lvReligion_u_c;
        private System.Windows.Forms.ColumnHeader lvReligion_d_k;
        private System.Windows.Forms.ColumnHeader lvReligion_d_c;
        private System.Windows.Forms.TextBox ur_hidden;
        private System.Windows.Forms.TextBox dr_hidden;
        private System.Windows.Forms.TextBox ur_hidden2;
        private System.Windows.Forms.TextBox dr_hidden2;
    }
}