﻿namespace myERP
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.r_group = new System.Windows.Forms.GroupBox();
            this.rb_position = new System.Windows.Forms.RadioButton();
            this.rb_depart = new System.Windows.Forms.RadioButton();
            this.rb_total = new System.Windows.Forms.RadioButton();
            this.rb_reason = new System.Windows.Forms.RadioButton();
            this.cb_report = new System.Windows.Forms.ComboBox();
            this.btn_report = new System.Windows.Forms.Button();
            this.lv_Report = new System.Windows.Forms.ListView();
            this.r_group.SuspendLayout();
            this.SuspendLayout();
            // 
            // r_group
            // 
            this.r_group.Controls.Add(this.rb_position);
            this.r_group.Controls.Add(this.rb_depart);
            this.r_group.Controls.Add(this.rb_total);
            this.r_group.Controls.Add(this.rb_reason);
            this.r_group.Location = new System.Drawing.Point(167, 6);
            this.r_group.Name = "r_group";
            this.r_group.Size = new System.Drawing.Size(375, 48);
            this.r_group.TabIndex = 0;
            this.r_group.TabStop = false;
            this.r_group.UseCompatibleTextRendering = true;
            // 
            // rb_position
            // 
            this.rb_position.AutoSize = true;
            this.rb_position.Location = new System.Drawing.Point(307, 18);
            this.rb_position.Name = "rb_position";
            this.rb_position.Size = new System.Drawing.Size(58, 19);
            this.rb_position.TabIndex = 3;
            this.rb_position.TabStop = true;
            this.rb_position.Text = "직책";
            this.rb_position.UseVisualStyleBackColor = true;
            this.rb_position.CheckedChanged += new System.EventHandler(this.rb_position_CheckedChanged);
            // 
            // rb_depart
            // 
            this.rb_depart.AutoSize = true;
            this.rb_depart.Location = new System.Drawing.Point(216, 18);
            this.rb_depart.Name = "rb_depart";
            this.rb_depart.Size = new System.Drawing.Size(58, 19);
            this.rb_depart.TabIndex = 2;
            this.rb_depart.TabStop = true;
            this.rb_depart.Text = "부서";
            this.rb_depart.UseVisualStyleBackColor = true;
            this.rb_depart.CheckedChanged += new System.EventHandler(this.rb_depart_CheckedChanged);
            // 
            // rb_total
            // 
            this.rb_total.AutoSize = true;
            this.rb_total.Location = new System.Drawing.Point(15, 18);
            this.rb_total.Name = "rb_total";
            this.rb_total.Size = new System.Drawing.Size(58, 19);
            this.rb_total.TabIndex = 0;
            this.rb_total.TabStop = true;
            this.rb_total.Text = "전체";
            this.rb_total.UseVisualStyleBackColor = true;
            this.rb_total.CheckedChanged += new System.EventHandler(this.rb_total_CheckedChanged);
            // 
            // rb_reason
            // 
            this.rb_reason.AutoSize = true;
            this.rb_reason.Location = new System.Drawing.Point(106, 18);
            this.rb_reason.Name = "rb_reason";
            this.rb_reason.Size = new System.Drawing.Size(73, 19);
            this.rb_reason.TabIndex = 1;
            this.rb_reason.TabStop = true;
            this.rb_reason.Text = "퇴직자";
            this.rb_reason.UseVisualStyleBackColor = true;
            this.rb_reason.CheckedChanged += new System.EventHandler(this.rb_reason_CheckedChanged);
            // 
            // cb_report
            // 
            this.cb_report.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_report.Font = new System.Drawing.Font("굴림", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb_report.FormattingEnabled = true;
            this.cb_report.Location = new System.Drawing.Point(172, 59);
            this.cb_report.Name = "cb_report";
            this.cb_report.Size = new System.Drawing.Size(359, 35);
            this.cb_report.TabIndex = 1;
            // 
            // btn_report
            // 
            this.btn_report.Location = new System.Drawing.Point(543, 59);
            this.btn_report.Name = "btn_report";
            this.btn_report.Size = new System.Drawing.Size(100, 35);
            this.btn_report.TabIndex = 2;
            this.btn_report.Text = "조회";
            this.btn_report.UseVisualStyleBackColor = true;
            this.btn_report.Click += new System.EventHandler(this.btn_report_Click);
            // 
            // lv_Report
            // 
            this.lv_Report.Font = new System.Drawing.Font("굴림", 10F);
            this.lv_Report.GridLines = true;
            this.lv_Report.Location = new System.Drawing.Point(27, 126);
            this.lv_Report.Name = "lv_Report";
            this.lv_Report.Size = new System.Drawing.Size(735, 298);
            this.lv_Report.TabIndex = 4;
            this.lv_Report.UseCompatibleStateImageBehavior = false;
            this.lv_Report.View = System.Windows.Forms.View.Details;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lv_Report);
            this.Controls.Add(this.btn_report);
            this.Controls.Add(this.cb_report);
            this.Controls.Add(this.r_group);
            this.Font = new System.Drawing.Font("굴림", 9F);
            this.Name = "Report";
            this.Text = "보고서";
            this.r_group.ResumeLayout(false);
            this.r_group.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox r_group;
        private System.Windows.Forms.RadioButton rb_position;
        private System.Windows.Forms.RadioButton rb_depart;
        private System.Windows.Forms.RadioButton rb_total;
        private System.Windows.Forms.RadioButton rb_reason;
        private System.Windows.Forms.ComboBox cb_report;
        private System.Windows.Forms.Button btn_report;
        private System.Windows.Forms.ListView lv_Report;
    }
}