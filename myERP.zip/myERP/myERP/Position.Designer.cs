﻿namespace myERP
{
    partial class Position
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p_TabMenu = new System.Windows.Forms.TabControl();
            this.p_Search = new System.Windows.Forms.TabPage();
            this.lvPosition_s = new System.Windows.Forms.ListView();
            this.lvPosition_s_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvPosition_s_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_p_search = new System.Windows.Forms.Button();
            this.s_position = new System.Windows.Forms.TextBox();
            this.lbl_s_position = new System.Windows.Forms.Label();
            this.p_Add = new System.Windows.Forms.TabPage();
            this.lvPosition_a = new System.Windows.Forms.ListView();
            this.lvPosition_a_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvPosition_a_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_p_add = new System.Windows.Forms.Button();
            this.a_p_code = new System.Windows.Forms.TextBox();
            this.a_position = new System.Windows.Forms.TextBox();
            this.lbl_a_p_code = new System.Windows.Forms.Label();
            this.lbl_a_position = new System.Windows.Forms.Label();
            this.p_Update = new System.Windows.Forms.TabPage();
            this.up_hidden2 = new System.Windows.Forms.TextBox();
            this.up_hidden = new System.Windows.Forms.TextBox();
            this.u_p_code = new System.Windows.Forms.TextBox();
            this.lbl_u_p_code = new System.Windows.Forms.Label();
            this.lvPosition_u = new System.Windows.Forms.ListView();
            this.lvPosition_u_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvPosition_u_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_p_update = new System.Windows.Forms.Button();
            this.u_position = new System.Windows.Forms.TextBox();
            this.lbl_u_positioin = new System.Windows.Forms.Label();
            this.p_Delete = new System.Windows.Forms.TabPage();
            this.dp_hidden = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.lvPosition_d = new System.Windows.Forms.ListView();
            this.lvPosition_d_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvPosition_d_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dp_hidden2 = new System.Windows.Forms.TextBox();
            this.p_TabMenu.SuspendLayout();
            this.p_Search.SuspendLayout();
            this.p_Add.SuspendLayout();
            this.p_Update.SuspendLayout();
            this.p_Delete.SuspendLayout();
            this.SuspendLayout();
            // 
            // p_TabMenu
            // 
            this.p_TabMenu.Controls.Add(this.p_Search);
            this.p_TabMenu.Controls.Add(this.p_Add);
            this.p_TabMenu.Controls.Add(this.p_Update);
            this.p_TabMenu.Controls.Add(this.p_Delete);
            this.p_TabMenu.Location = new System.Drawing.Point(0, 0);
            this.p_TabMenu.Name = "p_TabMenu";
            this.p_TabMenu.SelectedIndex = 0;
            this.p_TabMenu.Size = new System.Drawing.Size(386, 363);
            this.p_TabMenu.TabIndex = 0;
            this.p_TabMenu.SelectedIndexChanged += new System.EventHandler(this.p_TabMenu_SelectedIndexChanged);
            // 
            // p_Search
            // 
            this.p_Search.Controls.Add(this.lvPosition_s);
            this.p_Search.Controls.Add(this.btn_p_search);
            this.p_Search.Controls.Add(this.s_position);
            this.p_Search.Controls.Add(this.lbl_s_position);
            this.p_Search.Location = new System.Drawing.Point(4, 25);
            this.p_Search.Name = "p_Search";
            this.p_Search.Padding = new System.Windows.Forms.Padding(3);
            this.p_Search.Size = new System.Drawing.Size(378, 334);
            this.p_Search.TabIndex = 0;
            this.p_Search.Text = "조회";
            this.p_Search.UseVisualStyleBackColor = true;
            // 
            // lvPosition_s
            // 
            this.lvPosition_s.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvPosition_s_k,
            this.lvPosition_s_c});
            this.lvPosition_s.GridLines = true;
            this.lvPosition_s.Location = new System.Drawing.Point(30, 90);
            this.lvPosition_s.Name = "lvPosition_s";
            this.lvPosition_s.Size = new System.Drawing.Size(300, 200);
            this.lvPosition_s.TabIndex = 3;
            this.lvPosition_s.UseCompatibleStateImageBehavior = false;
            this.lvPosition_s.View = System.Windows.Forms.View.Details;
            // 
            // lvPosition_s_k
            // 
            this.lvPosition_s_k.Text = "직책";
            // 
            // lvPosition_s_c
            // 
            this.lvPosition_s_c.Text = "코드";
            // 
            // btn_p_search
            // 
            this.btn_p_search.Location = new System.Drawing.Point(230, 25);
            this.btn_p_search.Name = "btn_p_search";
            this.btn_p_search.Size = new System.Drawing.Size(60, 26);
            this.btn_p_search.TabIndex = 2;
            this.btn_p_search.Text = "찾기";
            this.btn_p_search.UseVisualStyleBackColor = true;
            this.btn_p_search.Click += new System.EventHandler(this.btn_p_search_Click);
            // 
            // s_position
            // 
            this.s_position.Location = new System.Drawing.Point(100, 25);
            this.s_position.Name = "s_position";
            this.s_position.Size = new System.Drawing.Size(100, 25);
            this.s_position.TabIndex = 1;
            // 
            // lbl_s_position
            // 
            this.lbl_s_position.AutoSize = true;
            this.lbl_s_position.Location = new System.Drawing.Point(27, 30);
            this.lbl_s_position.Name = "lbl_s_position";
            this.lbl_s_position.Size = new System.Drawing.Size(52, 15);
            this.lbl_s_position.TabIndex = 0;
            this.lbl_s_position.Text = "직책명";
            // 
            // p_Add
            // 
            this.p_Add.Controls.Add(this.lvPosition_a);
            this.p_Add.Controls.Add(this.btn_p_add);
            this.p_Add.Controls.Add(this.a_p_code);
            this.p_Add.Controls.Add(this.a_position);
            this.p_Add.Controls.Add(this.lbl_a_p_code);
            this.p_Add.Controls.Add(this.lbl_a_position);
            this.p_Add.Location = new System.Drawing.Point(4, 25);
            this.p_Add.Name = "p_Add";
            this.p_Add.Padding = new System.Windows.Forms.Padding(3);
            this.p_Add.Size = new System.Drawing.Size(378, 334);
            this.p_Add.TabIndex = 1;
            this.p_Add.Text = "등록";
            this.p_Add.UseVisualStyleBackColor = true;
            // 
            // lvPosition_a
            // 
            this.lvPosition_a.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvPosition_a_k,
            this.lvPosition_a_c});
            this.lvPosition_a.GridLines = true;
            this.lvPosition_a.Location = new System.Drawing.Point(30, 90);
            this.lvPosition_a.Name = "lvPosition_a";
            this.lvPosition_a.Size = new System.Drawing.Size(300, 200);
            this.lvPosition_a.TabIndex = 5;
            this.lvPosition_a.UseCompatibleStateImageBehavior = false;
            this.lvPosition_a.View = System.Windows.Forms.View.Details;
            // 
            // lvPosition_a_k
            // 
            this.lvPosition_a_k.Text = "직책";
            // 
            // lvPosition_a_c
            // 
            this.lvPosition_a_c.Text = "코드";
            // 
            // btn_p_add
            // 
            this.btn_p_add.Location = new System.Drawing.Point(255, 35);
            this.btn_p_add.Name = "btn_p_add";
            this.btn_p_add.Size = new System.Drawing.Size(75, 30);
            this.btn_p_add.TabIndex = 4;
            this.btn_p_add.Text = "추가하기";
            this.btn_p_add.UseVisualStyleBackColor = true;
            this.btn_p_add.Click += new System.EventHandler(this.btn_p_add_Click);
            // 
            // a_p_code
            // 
            this.a_p_code.Location = new System.Drawing.Point(100, 50);
            this.a_p_code.Name = "a_p_code";
            this.a_p_code.Size = new System.Drawing.Size(140, 25);
            this.a_p_code.TabIndex = 3;
            // 
            // a_position
            // 
            this.a_position.Location = new System.Drawing.Point(100, 15);
            this.a_position.Name = "a_position";
            this.a_position.Size = new System.Drawing.Size(140, 25);
            this.a_position.TabIndex = 2;
            // 
            // lbl_a_p_code
            // 
            this.lbl_a_p_code.AutoSize = true;
            this.lbl_a_p_code.Location = new System.Drawing.Point(36, 50);
            this.lbl_a_p_code.Name = "lbl_a_p_code";
            this.lbl_a_p_code.Size = new System.Drawing.Size(37, 15);
            this.lbl_a_p_code.TabIndex = 1;
            this.lbl_a_p_code.Text = "코드";
            // 
            // lbl_a_position
            // 
            this.lbl_a_position.AutoSize = true;
            this.lbl_a_position.Location = new System.Drawing.Point(36, 20);
            this.lbl_a_position.Name = "lbl_a_position";
            this.lbl_a_position.Size = new System.Drawing.Size(52, 15);
            this.lbl_a_position.TabIndex = 0;
            this.lbl_a_position.Text = "직책명";
            // 
            // p_Update
            // 
            this.p_Update.Controls.Add(this.up_hidden2);
            this.p_Update.Controls.Add(this.up_hidden);
            this.p_Update.Controls.Add(this.u_p_code);
            this.p_Update.Controls.Add(this.lbl_u_p_code);
            this.p_Update.Controls.Add(this.lvPosition_u);
            this.p_Update.Controls.Add(this.btn_p_update);
            this.p_Update.Controls.Add(this.u_position);
            this.p_Update.Controls.Add(this.lbl_u_positioin);
            this.p_Update.Location = new System.Drawing.Point(4, 25);
            this.p_Update.Name = "p_Update";
            this.p_Update.Padding = new System.Windows.Forms.Padding(3);
            this.p_Update.Size = new System.Drawing.Size(378, 334);
            this.p_Update.TabIndex = 2;
            this.p_Update.Text = "수정";
            this.p_Update.UseVisualStyleBackColor = true;
            // 
            // up_hidden2
            // 
            this.up_hidden2.Location = new System.Drawing.Point(198, 296);
            this.up_hidden2.Name = "up_hidden2";
            this.up_hidden2.Size = new System.Drawing.Size(100, 25);
            this.up_hidden2.TabIndex = 8;
            this.up_hidden2.Visible = false;
            // 
            // up_hidden
            // 
            this.up_hidden.Location = new System.Drawing.Point(113, 296);
            this.up_hidden.Name = "up_hidden";
            this.up_hidden.Size = new System.Drawing.Size(67, 25);
            this.up_hidden.TabIndex = 7;
            this.up_hidden.Visible = false;
            // 
            // u_p_code
            // 
            this.u_p_code.Location = new System.Drawing.Point(100, 50);
            this.u_p_code.Name = "u_p_code";
            this.u_p_code.Size = new System.Drawing.Size(140, 25);
            this.u_p_code.TabIndex = 6;
            // 
            // lbl_u_p_code
            // 
            this.lbl_u_p_code.AutoSize = true;
            this.lbl_u_p_code.Location = new System.Drawing.Point(36, 50);
            this.lbl_u_p_code.Name = "lbl_u_p_code";
            this.lbl_u_p_code.Size = new System.Drawing.Size(37, 15);
            this.lbl_u_p_code.TabIndex = 4;
            this.lbl_u_p_code.Text = "코드";
            // 
            // lvPosition_u
            // 
            this.lvPosition_u.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvPosition_u_k,
            this.lvPosition_u_c});
            this.lvPosition_u.GridLines = true;
            this.lvPosition_u.Location = new System.Drawing.Point(30, 90);
            this.lvPosition_u.Name = "lvPosition_u";
            this.lvPosition_u.Size = new System.Drawing.Size(300, 200);
            this.lvPosition_u.TabIndex = 3;
            this.lvPosition_u.UseCompatibleStateImageBehavior = false;
            this.lvPosition_u.View = System.Windows.Forms.View.Details;
            this.lvPosition_u.SelectedIndexChanged += new System.EventHandler(this.lvPosition_u_SelectedIndexChanged);
            // 
            // lvPosition_u_k
            // 
            this.lvPosition_u_k.Text = "직책";
            // 
            // lvPosition_u_c
            // 
            this.lvPosition_u_c.Text = "코드";
            // 
            // btn_p_update
            // 
            this.btn_p_update.Location = new System.Drawing.Point(255, 35);
            this.btn_p_update.Name = "btn_p_update";
            this.btn_p_update.Size = new System.Drawing.Size(75, 30);
            this.btn_p_update.TabIndex = 2;
            this.btn_p_update.Text = "수정하기";
            this.btn_p_update.UseVisualStyleBackColor = true;
            this.btn_p_update.Click += new System.EventHandler(this.btn_p_update_Click);
            // 
            // u_position
            // 
            this.u_position.Location = new System.Drawing.Point(100, 15);
            this.u_position.Name = "u_position";
            this.u_position.Size = new System.Drawing.Size(140, 25);
            this.u_position.TabIndex = 1;
            // 
            // lbl_u_positioin
            // 
            this.lbl_u_positioin.AutoSize = true;
            this.lbl_u_positioin.Location = new System.Drawing.Point(36, 20);
            this.lbl_u_positioin.Name = "lbl_u_positioin";
            this.lbl_u_positioin.Size = new System.Drawing.Size(52, 15);
            this.lbl_u_positioin.TabIndex = 0;
            this.lbl_u_positioin.Text = "직책명";
            // 
            // p_Delete
            // 
            this.p_Delete.Controls.Add(this.dp_hidden2);
            this.p_Delete.Controls.Add(this.dp_hidden);
            this.p_Delete.Controls.Add(this.btn_delete);
            this.p_Delete.Controls.Add(this.lvPosition_d);
            this.p_Delete.Location = new System.Drawing.Point(4, 25);
            this.p_Delete.Name = "p_Delete";
            this.p_Delete.Padding = new System.Windows.Forms.Padding(3);
            this.p_Delete.Size = new System.Drawing.Size(378, 334);
            this.p_Delete.TabIndex = 3;
            this.p_Delete.Text = "삭제";
            this.p_Delete.UseVisualStyleBackColor = true;
            // 
            // dp_hidden
            // 
            this.dp_hidden.Location = new System.Drawing.Point(9, 293);
            this.dp_hidden.Name = "dp_hidden";
            this.dp_hidden.Size = new System.Drawing.Size(100, 25);
            this.dp_hidden.TabIndex = 2;
            this.dp_hidden.Visible = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(294, 291);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 30);
            this.btn_delete.TabIndex = 1;
            this.btn_delete.Text = "삭제";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // lvPosition_d
            // 
            this.lvPosition_d.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvPosition_d_k,
            this.lvPosition_d_c});
            this.lvPosition_d.GridLines = true;
            this.lvPosition_d.Location = new System.Drawing.Point(8, 6);
            this.lvPosition_d.Name = "lvPosition_d";
            this.lvPosition_d.Size = new System.Drawing.Size(360, 270);
            this.lvPosition_d.TabIndex = 0;
            this.lvPosition_d.UseCompatibleStateImageBehavior = false;
            this.lvPosition_d.View = System.Windows.Forms.View.Details;
            this.lvPosition_d.SelectedIndexChanged += new System.EventHandler(this.lvPosition_d_SelectedIndexChanged);
            // 
            // lvPosition_d_k
            // 
            this.lvPosition_d_k.Text = "직책";
            // 
            // lvPosition_d_c
            // 
            this.lvPosition_d_c.Text = "코드";
            // 
            // dp_hidden2
            // 
            this.dp_hidden2.Location = new System.Drawing.Point(115, 293);
            this.dp_hidden2.Name = "dp_hidden2";
            this.dp_hidden2.Size = new System.Drawing.Size(100, 25);
            this.dp_hidden2.TabIndex = 3;
            this.dp_hidden2.Visible = false;
            // 
            // Position
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 361);
            this.Controls.Add(this.p_TabMenu);
            this.Name = "Position";
            this.Text = "직책 관리";
            this.p_TabMenu.ResumeLayout(false);
            this.p_Search.ResumeLayout(false);
            this.p_Search.PerformLayout();
            this.p_Add.ResumeLayout(false);
            this.p_Add.PerformLayout();
            this.p_Update.ResumeLayout(false);
            this.p_Update.PerformLayout();
            this.p_Delete.ResumeLayout(false);
            this.p_Delete.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl p_TabMenu;
        private System.Windows.Forms.TabPage p_Search;
        private System.Windows.Forms.TabPage p_Add;
        private System.Windows.Forms.TabPage p_Update;
        private System.Windows.Forms.TabPage p_Delete;
        private System.Windows.Forms.Label lbl_s_position;
        private System.Windows.Forms.ListView lvPosition_s;
        private System.Windows.Forms.ColumnHeader lvPosition_s_k;
        private System.Windows.Forms.ColumnHeader lvPosition_s_c;
        private System.Windows.Forms.Button btn_p_search;
        private System.Windows.Forms.TextBox s_position;
        private System.Windows.Forms.ListView lvPosition_a;
        private System.Windows.Forms.Button btn_p_add;
        private System.Windows.Forms.TextBox a_p_code;
        private System.Windows.Forms.TextBox a_position;
        private System.Windows.Forms.Label lbl_a_p_code;
        private System.Windows.Forms.Label lbl_a_position;
        private System.Windows.Forms.ColumnHeader lvPosition_a_k;
        private System.Windows.Forms.ColumnHeader lvPosition_a_c;
        private System.Windows.Forms.TextBox u_p_code;
        private System.Windows.Forms.Label lbl_u_p_code;
        private System.Windows.Forms.ListView lvPosition_u;
        private System.Windows.Forms.ColumnHeader lvPosition_u_k;
        private System.Windows.Forms.ColumnHeader lvPosition_u_c;
        private System.Windows.Forms.Button btn_p_update;
        private System.Windows.Forms.TextBox u_position;
        private System.Windows.Forms.Label lbl_u_positioin;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.ListView lvPosition_d;
        private System.Windows.Forms.ColumnHeader lvPosition_d_k;
        private System.Windows.Forms.ColumnHeader lvPosition_d_c;
        private System.Windows.Forms.TextBox up_hidden;
        private System.Windows.Forms.TextBox dp_hidden;
        private System.Windows.Forms.TextBox up_hidden2;
        private System.Windows.Forms.TextBox dp_hidden2;
    }
}