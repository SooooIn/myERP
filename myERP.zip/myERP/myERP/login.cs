﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myERP
{
    public partial class login : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public login()
        {
            InitializeComponent();

            m_id.Text = "mgr";
            m_pass.Text = "1234";
        }

        private void txtClear() // login_state 데이터 초기화
        {
            this.m_id.Text = "";
            this.m_pass.Text = "";
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var Comm = new SqlCommand("Select pass from t_login " + "where id = '" + this.m_id.Text + "'", Conn);
            var myRead = Comm.ExecuteReader();
            if(myRead.Read())
            {
                string strpwd = myRead[0].ToString();
                if(strpwd==this.m_pass.Text)
                {
                    myRead.Close();
                    Conn.Close();
                    
                    ERP_main main = new ERP_main();
                    //main.UserId = this.m_id.Text;
                    main.Show();
                    
                    this.Hide();
                }
                else
                {
                    this.login_state.Text = "로그인 실패";
                    txtClear();
                }
            }
            else
            {
                this.login_state.Text = "로그인 실패";
                txtClear();
            }
            myRead.Close();
            Conn.Close();
        }
    }
}
