﻿namespace myERP
{
    partial class Retired
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_r_id = new System.Windows.Forms.Label();
            this.btn_r_search = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.retire_hidden = new System.Windows.Forms.TextBox();
            this.lv_retired = new System.Windows.Forms.ListView();
            this.lv_retired_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_retired_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_served = new System.Windows.Forms.ListView();
            this.lv_served_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_served_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lbl_retired = new System.Windows.Forms.Label();
            this.lbl_served = new System.Windows.Forms.Label();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.tab_AU = new System.Windows.Forms.TabPage();
            this.cb_r_id = new System.Windows.Forms.ComboBox();
            this.btn_AU_update = new System.Windows.Forms.Button();
            this.r_layout = new System.Windows.Forms.TableLayoutPanel();
            this.cb_AU_position = new System.Windows.Forms.ComboBox();
            this.lbl_AU_position = new System.Windows.Forms.Label();
            this.lbl_AU_depart = new System.Windows.Forms.Label();
            this.lbl_AU_call = new System.Windows.Forms.Label();
            this.tb_AU_call = new System.Windows.Forms.TextBox();
            this.cb_AU_depart = new System.Windows.Forms.ComboBox();
            this.lbl_AU_date = new System.Windows.Forms.Label();
            this.dtp_AU_date = new System.Windows.Forms.DateTimePicker();
            this.lbl_AU_name = new System.Windows.Forms.Label();
            this.tb_AU_name = new System.Windows.Forms.TextBox();
            this.lbl_AU_reason = new System.Windows.Forms.Label();
            this.cb_AU_reason = new System.Windows.Forms.ComboBox();
            this.btn_AU_add = new System.Windows.Forms.Button();
            this.tab_S = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb_S_position = new System.Windows.Forms.RadioButton();
            this.rb_S_reason = new System.Windows.Forms.RadioButton();
            this.rb_S_date = new System.Windows.Forms.RadioButton();
            this.rb_S_depart = new System.Windows.Forms.RadioButton();
            this.lvRetired = new System.Windows.Forms.ListView();
            this.lvRetired_i = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvRetired_n = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvRetired_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvRetired_d = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvRetired_p = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvRetired_date = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvRetired_re = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tab_AU.SuspendLayout();
            this.r_layout.SuspendLayout();
            this.tab_S.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_r_id
            // 
            this.lbl_r_id.AutoSize = true;
            this.lbl_r_id.Location = new System.Drawing.Point(14, 22);
            this.lbl_r_id.Name = "lbl_r_id";
            this.lbl_r_id.Size = new System.Drawing.Size(67, 15);
            this.lbl_r_id.TabIndex = 0;
            this.lbl_r_id.Text = "사원번호";
            // 
            // btn_r_search
            // 
            this.btn_r_search.Location = new System.Drawing.Point(281, 19);
            this.btn_r_search.Name = "btn_r_search";
            this.btn_r_search.Size = new System.Drawing.Size(55, 25);
            this.btn_r_search.TabIndex = 2;
            this.btn_r_search.Text = "조회";
            this.btn_r_search.UseVisualStyleBackColor = true;
            this.btn_r_search.Click += new System.EventHandler(this.btn_r_search_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tab_AU);
            this.tabControl1.Controls.Add(this.tab_S);
            this.tabControl1.Location = new System.Drawing.Point(4, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(762, 282);
            this.tabControl1.TabIndex = 4;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.retire_hidden);
            this.tabPage1.Controls.Add(this.lv_retired);
            this.tabPage1.Controls.Add(this.lv_served);
            this.tabPage1.Controls.Add(this.lbl_retired);
            this.tabPage1.Controls.Add(this.lbl_served);
            this.tabPage1.Controls.Add(this.btn_del);
            this.tabPage1.Controls.Add(this.btn_add);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(754, 253);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "퇴직처리";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // retire_hidden
            // 
            this.retire_hidden.Location = new System.Drawing.Point(318, 219);
            this.retire_hidden.Name = "retire_hidden";
            this.retire_hidden.Size = new System.Drawing.Size(100, 25);
            this.retire_hidden.TabIndex = 13;
            this.retire_hidden.Visible = false;
            // 
            // lv_retired
            // 
            this.lv_retired.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lv_retired_id,
            this.lv_retired_name});
            this.lv_retired.GridLines = true;
            this.lv_retired.Location = new System.Drawing.Point(450, 30);
            this.lv_retired.Name = "lv_retired";
            this.lv_retired.Size = new System.Drawing.Size(270, 214);
            this.lv_retired.TabIndex = 12;
            this.lv_retired.UseCompatibleStateImageBehavior = false;
            this.lv_retired.View = System.Windows.Forms.View.Details;
            this.lv_retired.SelectedIndexChanged += new System.EventHandler(this.lv_retired_SelectedIndexChanged);
            // 
            // lv_retired_id
            // 
            this.lv_retired_id.Text = "사번";
            // 
            // lv_retired_name
            // 
            this.lv_retired_name.Text = "성명";
            // 
            // lv_served
            // 
            this.lv_served.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lv_served_id,
            this.lv_served_name});
            this.lv_served.GridLines = true;
            this.lv_served.Location = new System.Drawing.Point(21, 30);
            this.lv_served.Name = "lv_served";
            this.lv_served.Size = new System.Drawing.Size(270, 214);
            this.lv_served.TabIndex = 11;
            this.lv_served.UseCompatibleStateImageBehavior = false;
            this.lv_served.View = System.Windows.Forms.View.Details;
            this.lv_served.SelectedIndexChanged += new System.EventHandler(this.lv_served_SelectedIndexChanged);
            // 
            // lv_served_id
            // 
            this.lv_served_id.Text = "사번";
            // 
            // lv_served_name
            // 
            this.lv_served_name.Text = "성명";
            // 
            // lbl_retired
            // 
            this.lbl_retired.AutoSize = true;
            this.lbl_retired.Location = new System.Drawing.Point(456, 12);
            this.lbl_retired.Name = "lbl_retired";
            this.lbl_retired.Size = new System.Drawing.Size(37, 15);
            this.lbl_retired.TabIndex = 10;
            this.lbl_retired.Text = "퇴직";
            // 
            // lbl_served
            // 
            this.lbl_served.AutoSize = true;
            this.lbl_served.Location = new System.Drawing.Point(27, 12);
            this.lbl_served.Name = "lbl_served";
            this.lbl_served.Size = new System.Drawing.Size(37, 15);
            this.lbl_served.TabIndex = 9;
            this.lbl_served.Text = "재직";
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(357, 135);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(30, 30);
            this.btn_del.TabIndex = 8;
            this.btn_del.Text = "<";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(357, 82);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(30, 30);
            this.btn_add.TabIndex = 7;
            this.btn_add.Text = ">";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // tab_AU
            // 
            this.tab_AU.Controls.Add(this.cb_r_id);
            this.tab_AU.Controls.Add(this.btn_AU_update);
            this.tab_AU.Controls.Add(this.btn_r_search);
            this.tab_AU.Controls.Add(this.r_layout);
            this.tab_AU.Controls.Add(this.lbl_r_id);
            this.tab_AU.Controls.Add(this.btn_AU_add);
            this.tab_AU.Location = new System.Drawing.Point(4, 25);
            this.tab_AU.Name = "tab_AU";
            this.tab_AU.Padding = new System.Windows.Forms.Padding(3);
            this.tab_AU.Size = new System.Drawing.Size(754, 253);
            this.tab_AU.TabIndex = 0;
            this.tab_AU.Text = "세부사항";
            this.tab_AU.UseVisualStyleBackColor = true;
            // 
            // cb_r_id
            // 
            this.cb_r_id.FormattingEnabled = true;
            this.cb_r_id.Location = new System.Drawing.Point(102, 19);
            this.cb_r_id.Name = "cb_r_id";
            this.cb_r_id.Size = new System.Drawing.Size(156, 23);
            this.cb_r_id.TabIndex = 5;
            // 
            // btn_AU_update
            // 
            this.btn_AU_update.Location = new System.Drawing.Point(655, 198);
            this.btn_AU_update.Name = "btn_AU_update";
            this.btn_AU_update.Size = new System.Drawing.Size(75, 36);
            this.btn_AU_update.TabIndex = 19;
            this.btn_AU_update.Text = "수정";
            this.btn_AU_update.UseVisualStyleBackColor = true;
            this.btn_AU_update.Click += new System.EventHandler(this.btn_AU_update_Click);
            // 
            // r_layout
            // 
            this.r_layout.ColumnCount = 6;
            this.r_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.r_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 161F));
            this.r_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.r_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.r_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.r_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 151F));
            this.r_layout.Controls.Add(this.cb_AU_position, 5, 0);
            this.r_layout.Controls.Add(this.lbl_AU_position, 4, 0);
            this.r_layout.Controls.Add(this.lbl_AU_depart, 2, 1);
            this.r_layout.Controls.Add(this.lbl_AU_call, 2, 0);
            this.r_layout.Controls.Add(this.tb_AU_call, 3, 0);
            this.r_layout.Controls.Add(this.cb_AU_depart, 3, 1);
            this.r_layout.Controls.Add(this.lbl_AU_date, 4, 1);
            this.r_layout.Controls.Add(this.dtp_AU_date, 5, 1);
            this.r_layout.Controls.Add(this.lbl_AU_name, 0, 0);
            this.r_layout.Controls.Add(this.tb_AU_name, 1, 0);
            this.r_layout.Controls.Add(this.lbl_AU_reason, 0, 1);
            this.r_layout.Controls.Add(this.cb_AU_reason, 1, 1);
            this.r_layout.Location = new System.Drawing.Point(11, 73);
            this.r_layout.Name = "r_layout";
            this.r_layout.RowCount = 2;
            this.r_layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.r_layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.r_layout.Size = new System.Drawing.Size(734, 66);
            this.r_layout.TabIndex = 16;
            // 
            // cb_AU_position
            // 
            this.cb_AU_position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_AU_position.Enabled = false;
            this.cb_AU_position.FormattingEnabled = true;
            this.cb_AU_position.Location = new System.Drawing.Point(586, 3);
            this.cb_AU_position.Name = "cb_AU_position";
            this.cb_AU_position.Size = new System.Drawing.Size(145, 23);
            this.cb_AU_position.TabIndex = 12;
            // 
            // lbl_AU_position
            // 
            this.lbl_AU_position.AutoSize = true;
            this.lbl_AU_position.Location = new System.Drawing.Point(496, 0);
            this.lbl_AU_position.Name = "lbl_AU_position";
            this.lbl_AU_position.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_AU_position.Size = new System.Drawing.Size(37, 29);
            this.lbl_AU_position.TabIndex = 10;
            this.lbl_AU_position.Text = "직책";
            // 
            // lbl_AU_depart
            // 
            this.lbl_AU_depart.AutoSize = true;
            this.lbl_AU_depart.Location = new System.Drawing.Point(248, 31);
            this.lbl_AU_depart.Name = "lbl_AU_depart";
            this.lbl_AU_depart.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_AU_depart.Size = new System.Drawing.Size(37, 29);
            this.lbl_AU_depart.TabIndex = 9;
            this.lbl_AU_depart.Text = "부서";
            // 
            // lbl_AU_call
            // 
            this.lbl_AU_call.AutoSize = true;
            this.lbl_AU_call.Location = new System.Drawing.Point(248, 0);
            this.lbl_AU_call.Name = "lbl_AU_call";
            this.lbl_AU_call.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_AU_call.Size = new System.Drawing.Size(52, 29);
            this.lbl_AU_call.TabIndex = 8;
            this.lbl_AU_call.Text = "연락처";
            // 
            // tb_AU_call
            // 
            this.tb_AU_call.Enabled = false;
            this.tb_AU_call.Location = new System.Drawing.Point(336, 3);
            this.tb_AU_call.Name = "tb_AU_call";
            this.tb_AU_call.Size = new System.Drawing.Size(154, 25);
            this.tb_AU_call.TabIndex = 14;
            // 
            // cb_AU_depart
            // 
            this.cb_AU_depart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_AU_depart.Enabled = false;
            this.cb_AU_depart.FormattingEnabled = true;
            this.cb_AU_depart.Location = new System.Drawing.Point(336, 34);
            this.cb_AU_depart.Name = "cb_AU_depart";
            this.cb_AU_depart.Size = new System.Drawing.Size(154, 23);
            this.cb_AU_depart.TabIndex = 15;
            // 
            // lbl_AU_date
            // 
            this.lbl_AU_date.AutoSize = true;
            this.lbl_AU_date.Location = new System.Drawing.Point(496, 31);
            this.lbl_AU_date.Name = "lbl_AU_date";
            this.lbl_AU_date.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_AU_date.Size = new System.Drawing.Size(82, 29);
            this.lbl_AU_date.TabIndex = 16;
            this.lbl_AU_date.Text = "퇴직년월일";
            // 
            // dtp_AU_date
            // 
            this.dtp_AU_date.Location = new System.Drawing.Point(586, 34);
            this.dtp_AU_date.Name = "dtp_AU_date";
            this.dtp_AU_date.Size = new System.Drawing.Size(145, 25);
            this.dtp_AU_date.TabIndex = 17;
            // 
            // lbl_AU_name
            // 
            this.lbl_AU_name.AutoSize = true;
            this.lbl_AU_name.Location = new System.Drawing.Point(3, 0);
            this.lbl_AU_name.Name = "lbl_AU_name";
            this.lbl_AU_name.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_AU_name.Size = new System.Drawing.Size(37, 29);
            this.lbl_AU_name.TabIndex = 7;
            this.lbl_AU_name.Text = "이름";
            // 
            // tb_AU_name
            // 
            this.tb_AU_name.Enabled = false;
            this.tb_AU_name.Location = new System.Drawing.Point(87, 3);
            this.tb_AU_name.Name = "tb_AU_name";
            this.tb_AU_name.Size = new System.Drawing.Size(155, 25);
            this.tb_AU_name.TabIndex = 13;
            // 
            // lbl_AU_reason
            // 
            this.lbl_AU_reason.AutoSize = true;
            this.lbl_AU_reason.Location = new System.Drawing.Point(3, 31);
            this.lbl_AU_reason.Name = "lbl_AU_reason";
            this.lbl_AU_reason.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_AU_reason.Size = new System.Drawing.Size(67, 29);
            this.lbl_AU_reason.TabIndex = 11;
            this.lbl_AU_reason.Text = "퇴직사유";
            // 
            // cb_AU_reason
            // 
            this.cb_AU_reason.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_AU_reason.FormattingEnabled = true;
            this.cb_AU_reason.Location = new System.Drawing.Point(87, 34);
            this.cb_AU_reason.Name = "cb_AU_reason";
            this.cb_AU_reason.Size = new System.Drawing.Size(155, 23);
            this.cb_AU_reason.TabIndex = 13;
            // 
            // btn_AU_add
            // 
            this.btn_AU_add.Location = new System.Drawing.Point(554, 198);
            this.btn_AU_add.Name = "btn_AU_add";
            this.btn_AU_add.Size = new System.Drawing.Size(75, 36);
            this.btn_AU_add.TabIndex = 18;
            this.btn_AU_add.Text = "추가";
            this.btn_AU_add.UseVisualStyleBackColor = true;
            this.btn_AU_add.Click += new System.EventHandler(this.btn_AU_add_Click);
            // 
            // tab_S
            // 
            this.tab_S.Controls.Add(this.groupBox1);
            this.tab_S.Controls.Add(this.lvRetired);
            this.tab_S.Location = new System.Drawing.Point(4, 25);
            this.tab_S.Name = "tab_S";
            this.tab_S.Padding = new System.Windows.Forms.Padding(3);
            this.tab_S.Size = new System.Drawing.Size(754, 253);
            this.tab_S.TabIndex = 1;
            this.tab_S.Text = "전체조회";
            this.tab_S.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb_S_position);
            this.groupBox1.Controls.Add(this.rb_S_reason);
            this.groupBox1.Controls.Add(this.rb_S_date);
            this.groupBox1.Controls.Add(this.rb_S_depart);
            this.groupBox1.Location = new System.Drawing.Point(11, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(348, 38);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // rb_S_position
            // 
            this.rb_S_position.AutoSize = true;
            this.rb_S_position.Location = new System.Drawing.Point(284, 13);
            this.rb_S_position.Name = "rb_S_position";
            this.rb_S_position.Size = new System.Drawing.Size(58, 19);
            this.rb_S_position.TabIndex = 9;
            this.rb_S_position.TabStop = true;
            this.rb_S_position.Text = "직책";
            this.rb_S_position.UseVisualStyleBackColor = true;
            this.rb_S_position.CheckedChanged += new System.EventHandler(this.rb_S_position_CheckedChanged);
            // 
            // rb_S_reason
            // 
            this.rb_S_reason.AutoSize = true;
            this.rb_S_reason.Location = new System.Drawing.Point(6, 13);
            this.rb_S_reason.Name = "rb_S_reason";
            this.rb_S_reason.Size = new System.Drawing.Size(88, 19);
            this.rb_S_reason.TabIndex = 6;
            this.rb_S_reason.TabStop = true;
            this.rb_S_reason.Text = "퇴직사유";
            this.rb_S_reason.UseVisualStyleBackColor = true;
            this.rb_S_reason.CheckedChanged += new System.EventHandler(this.rb_S_reason_CheckedChanged);
            // 
            // rb_S_date
            // 
            this.rb_S_date.AutoSize = true;
            this.rb_S_date.Location = new System.Drawing.Point(194, 13);
            this.rb_S_date.Name = "rb_S_date";
            this.rb_S_date.Size = new System.Drawing.Size(88, 19);
            this.rb_S_date.TabIndex = 8;
            this.rb_S_date.TabStop = true;
            this.rb_S_date.Text = "퇴직날짜";
            this.rb_S_date.UseVisualStyleBackColor = true;
            this.rb_S_date.CheckedChanged += new System.EventHandler(this.rb_S_date_CheckedChanged);
            // 
            // rb_S_depart
            // 
            this.rb_S_depart.AutoSize = true;
            this.rb_S_depart.Location = new System.Drawing.Point(100, 13);
            this.rb_S_depart.Name = "rb_S_depart";
            this.rb_S_depart.Size = new System.Drawing.Size(88, 19);
            this.rb_S_depart.TabIndex = 7;
            this.rb_S_depart.TabStop = true;
            this.rb_S_depart.Text = "근무부서";
            this.rb_S_depart.UseVisualStyleBackColor = true;
            this.rb_S_depart.CheckedChanged += new System.EventHandler(this.rb_S_depart_CheckedChanged);
            // 
            // lvRetired
            // 
            this.lvRetired.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvRetired_i,
            this.lvRetired_n,
            this.lvRetired_c,
            this.lvRetired_d,
            this.lvRetired_p,
            this.lvRetired_date,
            this.lvRetired_re});
            this.lvRetired.GridLines = true;
            this.lvRetired.Location = new System.Drawing.Point(11, 45);
            this.lvRetired.Name = "lvRetired";
            this.lvRetired.Size = new System.Drawing.Size(723, 128);
            this.lvRetired.TabIndex = 4;
            this.lvRetired.UseCompatibleStateImageBehavior = false;
            this.lvRetired.View = System.Windows.Forms.View.Details;
            // 
            // lvRetired_i
            // 
            this.lvRetired_i.Text = "사번";
            this.lvRetired_i.Width = 100;
            // 
            // lvRetired_n
            // 
            this.lvRetired_n.Text = "이름";
            this.lvRetired_n.Width = 100;
            // 
            // lvRetired_c
            // 
            this.lvRetired_c.Text = "연락처";
            this.lvRetired_c.Width = 80;
            // 
            // lvRetired_d
            // 
            this.lvRetired_d.Text = "부서";
            this.lvRetired_d.Width = 80;
            // 
            // lvRetired_p
            // 
            this.lvRetired_p.Text = "직책";
            this.lvRetired_p.Width = 80;
            // 
            // lvRetired_date
            // 
            this.lvRetired_date.Text = "퇴직년월일";
            this.lvRetired_date.Width = 100;
            // 
            // lvRetired_re
            // 
            this.lvRetired_re.Text = "사유";
            this.lvRetired_re.Width = 120;
            // 
            // Retired
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 286);
            this.Controls.Add(this.tabControl1);
            this.Name = "Retired";
            this.Text = "퇴직자 관리";
            this.Load += new System.EventHandler(this.Retired_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tab_AU.ResumeLayout(false);
            this.tab_AU.PerformLayout();
            this.r_layout.ResumeLayout(false);
            this.r_layout.PerformLayout();
            this.tab_S.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_r_id;
        private System.Windows.Forms.Button btn_r_search;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_AU;
        private System.Windows.Forms.Button btn_AU_update;
        private System.Windows.Forms.TableLayoutPanel r_layout;
        private System.Windows.Forms.ComboBox cb_AU_reason;
        private System.Windows.Forms.ComboBox cb_AU_position;
        private System.Windows.Forms.Label lbl_AU_name;
        private System.Windows.Forms.Label lbl_AU_position;
        private System.Windows.Forms.Label lbl_AU_reason;
        private System.Windows.Forms.TextBox tb_AU_name;
        private System.Windows.Forms.Label lbl_AU_depart;
        private System.Windows.Forms.Label lbl_AU_call;
        private System.Windows.Forms.TextBox tb_AU_call;
        private System.Windows.Forms.ComboBox cb_AU_depart;
        private System.Windows.Forms.Label lbl_AU_date;
        private System.Windows.Forms.DateTimePicker dtp_AU_date;
        private System.Windows.Forms.Button btn_AU_add;
        private System.Windows.Forms.TabPage tab_S;
        private System.Windows.Forms.ListView lvRetired;
        private System.Windows.Forms.ColumnHeader lvRetired_i;
        private System.Windows.Forms.ColumnHeader lvRetired_n;
        private System.Windows.Forms.ColumnHeader lvRetired_c;
        private System.Windows.Forms.ColumnHeader lvRetired_d;
        private System.Windows.Forms.ColumnHeader lvRetired_p;
        private System.Windows.Forms.ColumnHeader lvRetired_date;
        private System.Windows.Forms.ColumnHeader lvRetired_re;
        private System.Windows.Forms.ComboBox cb_r_id;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb_S_reason;
        private System.Windows.Forms.RadioButton rb_S_depart;
        private System.Windows.Forms.RadioButton rb_S_date;
        private System.Windows.Forms.RadioButton rb_S_position;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lbl_retired;
        private System.Windows.Forms.Label lbl_served;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ListView lv_retired;
        private System.Windows.Forms.ListView lv_served;
        private System.Windows.Forms.ColumnHeader lv_served_id;
        private System.Windows.Forms.ColumnHeader lv_served_name;
        private System.Windows.Forms.ColumnHeader lv_retired_id;
        private System.Windows.Forms.ColumnHeader lv_retired_name;
        private System.Windows.Forms.TextBox retire_hidden;
    }
}