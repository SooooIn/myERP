﻿namespace myERP
{
    partial class login
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_m_id = new System.Windows.Forms.Label();
            this.lbl_m_pass = new System.Windows.Forms.Label();
            this.btn_Login = new System.Windows.Forms.Button();
            this.m_id = new System.Windows.Forms.TextBox();
            this.m_pass = new System.Windows.Forms.TextBox();
            this.login_state = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_m_id
            // 
            this.lbl_m_id.AutoSize = true;
            this.lbl_m_id.Location = new System.Drawing.Point(23, 25);
            this.lbl_m_id.Name = "lbl_m_id";
            this.lbl_m_id.Size = new System.Drawing.Size(92, 15);
            this.lbl_m_id.TabIndex = 0;
            this.lbl_m_id.Text = "ID(사원번호)";
            // 
            // lbl_m_pass
            // 
            this.lbl_m_pass.AutoSize = true;
            this.lbl_m_pass.Location = new System.Drawing.Point(23, 58);
            this.lbl_m_pass.Name = "lbl_m_pass";
            this.lbl_m_pass.Size = new System.Drawing.Size(41, 15);
            this.lbl_m_pass.TabIndex = 1;
            this.lbl_m_pass.Text = "PWD";
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(201, 96);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(76, 27);
            this.btn_Login.TabIndex = 2;
            this.btn_Login.Text = "확인";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // m_id
            // 
            this.m_id.Location = new System.Drawing.Point(133, 20);
            this.m_id.Name = "m_id";
            this.m_id.Size = new System.Drawing.Size(144, 25);
            this.m_id.TabIndex = 3;
            // 
            // m_pass
            // 
            this.m_pass.Location = new System.Drawing.Point(133, 54);
            this.m_pass.Name = "m_pass";
            this.m_pass.Size = new System.Drawing.Size(144, 25);
            this.m_pass.TabIndex = 4;
            // 
            // login_state
            // 
            this.login_state.AutoSize = true;
            this.login_state.Location = new System.Drawing.Point(23, 133);
            this.login_state.Name = "login_state";
            this.login_state.Size = new System.Drawing.Size(0, 15);
            this.login_state.TabIndex = 5;
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 169);
            this.Controls.Add(this.login_state);
            this.Controls.Add(this.m_pass);
            this.Controls.Add(this.m_id);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.lbl_m_pass);
            this.Controls.Add(this.lbl_m_id);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "login";
            this.Text = "로그인";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_m_id;
        private System.Windows.Forms.Label lbl_m_pass;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox m_id;
        private System.Windows.Forms.TextBox m_pass;
        private System.Windows.Forms.Label login_state;
    }
}

