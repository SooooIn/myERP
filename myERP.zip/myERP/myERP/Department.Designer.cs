﻿namespace myERP
{
    partial class Department
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.d_tabMenu = new System.Windows.Forms.TabControl();
            this.d_Search = new System.Windows.Forms.TabPage();
            this.lvDepart_s = new System.Windows.Forms.ListView();
            this.lvDepart_s_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvDepart_s_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_d_search = new System.Windows.Forms.Button();
            this.s_depart = new System.Windows.Forms.TextBox();
            this.lbl_s_depart = new System.Windows.Forms.Label();
            this.d_Add = new System.Windows.Forms.TabPage();
            this.lvDepart_a = new System.Windows.Forms.ListView();
            this.lvDepart_a_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvDepart_a_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_d_add = new System.Windows.Forms.Button();
            this.a_d_code = new System.Windows.Forms.TextBox();
            this.a_depart = new System.Windows.Forms.TextBox();
            this.lbl_a_d_code = new System.Windows.Forms.Label();
            this.lbl_a_depart = new System.Windows.Forms.Label();
            this.d_Update = new System.Windows.Forms.TabPage();
            this.ud_hidden = new System.Windows.Forms.TextBox();
            this.lvDepart_u = new System.Windows.Forms.ListView();
            this.lvDepart_u_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvDepart_u_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_d_update = new System.Windows.Forms.Button();
            this.u_d_code = new System.Windows.Forms.TextBox();
            this.u_depart = new System.Windows.Forms.TextBox();
            this.lbl_u_d_code = new System.Windows.Forms.Label();
            this.lbl_u_depart = new System.Windows.Forms.Label();
            this.d_Delete = new System.Windows.Forms.TabPage();
            this.dd_hidden = new System.Windows.Forms.TextBox();
            this.btn_d_delete = new System.Windows.Forms.Button();
            this.lvDepart_d = new System.Windows.Forms.ListView();
            this.lvDepart_d_k = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvDepart_d_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ud_hidden2 = new System.Windows.Forms.TextBox();
            this.dd_hidden2 = new System.Windows.Forms.TextBox();
            this.d_tabMenu.SuspendLayout();
            this.d_Search.SuspendLayout();
            this.d_Add.SuspendLayout();
            this.d_Update.SuspendLayout();
            this.d_Delete.SuspendLayout();
            this.SuspendLayout();
            // 
            // d_tabMenu
            // 
            this.d_tabMenu.Controls.Add(this.d_Search);
            this.d_tabMenu.Controls.Add(this.d_Add);
            this.d_tabMenu.Controls.Add(this.d_Update);
            this.d_tabMenu.Controls.Add(this.d_Delete);
            this.d_tabMenu.Location = new System.Drawing.Point(0, 0);
            this.d_tabMenu.Name = "d_tabMenu";
            this.d_tabMenu.SelectedIndex = 0;
            this.d_tabMenu.Size = new System.Drawing.Size(386, 363);
            this.d_tabMenu.TabIndex = 0;
            this.d_tabMenu.SelectedIndexChanged += new System.EventHandler(this.d_tabMenu_SelectedIndexChanged);
            // 
            // d_Search
            // 
            this.d_Search.Controls.Add(this.lvDepart_s);
            this.d_Search.Controls.Add(this.btn_d_search);
            this.d_Search.Controls.Add(this.s_depart);
            this.d_Search.Controls.Add(this.lbl_s_depart);
            this.d_Search.Location = new System.Drawing.Point(4, 25);
            this.d_Search.Name = "d_Search";
            this.d_Search.Padding = new System.Windows.Forms.Padding(3);
            this.d_Search.Size = new System.Drawing.Size(378, 334);
            this.d_Search.TabIndex = 0;
            this.d_Search.Text = "조회";
            this.d_Search.UseVisualStyleBackColor = true;
            // 
            // lvDepart_s
            // 
            this.lvDepart_s.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvDepart_s_k,
            this.lvDepart_s_c});
            this.lvDepart_s.GridLines = true;
            this.lvDepart_s.Location = new System.Drawing.Point(30, 90);
            this.lvDepart_s.Name = "lvDepart_s";
            this.lvDepart_s.Size = new System.Drawing.Size(300, 200);
            this.lvDepart_s.TabIndex = 3;
            this.lvDepart_s.UseCompatibleStateImageBehavior = false;
            this.lvDepart_s.View = System.Windows.Forms.View.Details;
            // 
            // lvDepart_s_k
            // 
            this.lvDepart_s_k.Text = "부서";
            // 
            // lvDepart_s_c
            // 
            this.lvDepart_s_c.Text = "코드";
            // 
            // btn_d_search
            // 
            this.btn_d_search.Location = new System.Drawing.Point(230, 25);
            this.btn_d_search.Name = "btn_d_search";
            this.btn_d_search.Size = new System.Drawing.Size(60, 26);
            this.btn_d_search.TabIndex = 2;
            this.btn_d_search.Text = "찾기";
            this.btn_d_search.UseVisualStyleBackColor = true;
            this.btn_d_search.Click += new System.EventHandler(this.btn_d_search_Click);
            // 
            // s_depart
            // 
            this.s_depart.Location = new System.Drawing.Point(100, 25);
            this.s_depart.Name = "s_depart";
            this.s_depart.Size = new System.Drawing.Size(100, 25);
            this.s_depart.TabIndex = 1;
            // 
            // lbl_s_depart
            // 
            this.lbl_s_depart.AutoSize = true;
            this.lbl_s_depart.Location = new System.Drawing.Point(27, 30);
            this.lbl_s_depart.Name = "lbl_s_depart";
            this.lbl_s_depart.Size = new System.Drawing.Size(52, 15);
            this.lbl_s_depart.TabIndex = 0;
            this.lbl_s_depart.Text = "부서명";
            // 
            // d_Add
            // 
            this.d_Add.Controls.Add(this.lvDepart_a);
            this.d_Add.Controls.Add(this.btn_d_add);
            this.d_Add.Controls.Add(this.a_d_code);
            this.d_Add.Controls.Add(this.a_depart);
            this.d_Add.Controls.Add(this.lbl_a_d_code);
            this.d_Add.Controls.Add(this.lbl_a_depart);
            this.d_Add.Location = new System.Drawing.Point(4, 25);
            this.d_Add.Name = "d_Add";
            this.d_Add.Padding = new System.Windows.Forms.Padding(3);
            this.d_Add.Size = new System.Drawing.Size(378, 334);
            this.d_Add.TabIndex = 1;
            this.d_Add.Text = "등록";
            this.d_Add.UseVisualStyleBackColor = true;
            // 
            // lvDepart_a
            // 
            this.lvDepart_a.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvDepart_a_k,
            this.lvDepart_a_c});
            this.lvDepart_a.GridLines = true;
            this.lvDepart_a.Location = new System.Drawing.Point(30, 90);
            this.lvDepart_a.Name = "lvDepart_a";
            this.lvDepart_a.Size = new System.Drawing.Size(300, 200);
            this.lvDepart_a.TabIndex = 11;
            this.lvDepart_a.UseCompatibleStateImageBehavior = false;
            this.lvDepart_a.View = System.Windows.Forms.View.Details;
            // 
            // lvDepart_a_k
            // 
            this.lvDepart_a_k.Text = "부서";
            // 
            // lvDepart_a_c
            // 
            this.lvDepart_a_c.Text = "코드";
            // 
            // btn_d_add
            // 
            this.btn_d_add.Location = new System.Drawing.Point(255, 35);
            this.btn_d_add.Name = "btn_d_add";
            this.btn_d_add.Size = new System.Drawing.Size(75, 30);
            this.btn_d_add.TabIndex = 10;
            this.btn_d_add.Text = "추가하기";
            this.btn_d_add.UseVisualStyleBackColor = true;
            this.btn_d_add.Click += new System.EventHandler(this.btn_d_add_Click);
            // 
            // a_d_code
            // 
            this.a_d_code.Location = new System.Drawing.Point(100, 50);
            this.a_d_code.Name = "a_d_code";
            this.a_d_code.Size = new System.Drawing.Size(140, 25);
            this.a_d_code.TabIndex = 9;
            // 
            // a_depart
            // 
            this.a_depart.Location = new System.Drawing.Point(100, 15);
            this.a_depart.Name = "a_depart";
            this.a_depart.Size = new System.Drawing.Size(140, 25);
            this.a_depart.TabIndex = 8;
            // 
            // lbl_a_d_code
            // 
            this.lbl_a_d_code.AutoSize = true;
            this.lbl_a_d_code.Location = new System.Drawing.Point(36, 50);
            this.lbl_a_d_code.Name = "lbl_a_d_code";
            this.lbl_a_d_code.Size = new System.Drawing.Size(37, 15);
            this.lbl_a_d_code.TabIndex = 7;
            this.lbl_a_d_code.Text = "코드";
            // 
            // lbl_a_depart
            // 
            this.lbl_a_depart.AutoSize = true;
            this.lbl_a_depart.Location = new System.Drawing.Point(36, 20);
            this.lbl_a_depart.Name = "lbl_a_depart";
            this.lbl_a_depart.Size = new System.Drawing.Size(52, 15);
            this.lbl_a_depart.TabIndex = 6;
            this.lbl_a_depart.Text = "부서명";
            // 
            // d_Update
            // 
            this.d_Update.Controls.Add(this.ud_hidden2);
            this.d_Update.Controls.Add(this.ud_hidden);
            this.d_Update.Controls.Add(this.lvDepart_u);
            this.d_Update.Controls.Add(this.btn_d_update);
            this.d_Update.Controls.Add(this.u_d_code);
            this.d_Update.Controls.Add(this.u_depart);
            this.d_Update.Controls.Add(this.lbl_u_d_code);
            this.d_Update.Controls.Add(this.lbl_u_depart);
            this.d_Update.Location = new System.Drawing.Point(4, 25);
            this.d_Update.Name = "d_Update";
            this.d_Update.Padding = new System.Windows.Forms.Padding(3);
            this.d_Update.Size = new System.Drawing.Size(378, 334);
            this.d_Update.TabIndex = 2;
            this.d_Update.Text = "수정";
            this.d_Update.UseVisualStyleBackColor = true;
            // 
            // ud_hidden
            // 
            this.ud_hidden.Location = new System.Drawing.Point(143, 296);
            this.ud_hidden.Name = "ud_hidden";
            this.ud_hidden.Size = new System.Drawing.Size(75, 25);
            this.ud_hidden.TabIndex = 6;
            this.ud_hidden.Visible = false;
            // 
            // lvDepart_u
            // 
            this.lvDepart_u.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvDepart_u_k,
            this.lvDepart_u_c});
            this.lvDepart_u.GridLines = true;
            this.lvDepart_u.Location = new System.Drawing.Point(30, 90);
            this.lvDepart_u.Name = "lvDepart_u";
            this.lvDepart_u.Size = new System.Drawing.Size(300, 200);
            this.lvDepart_u.TabIndex = 5;
            this.lvDepart_u.UseCompatibleStateImageBehavior = false;
            this.lvDepart_u.View = System.Windows.Forms.View.Details;
            this.lvDepart_u.SelectedIndexChanged += new System.EventHandler(this.lvDepart_u_SelectedIndexChanged);
            // 
            // lvDepart_u_k
            // 
            this.lvDepart_u_k.Text = "부서";
            // 
            // lvDepart_u_c
            // 
            this.lvDepart_u_c.Text = "코드";
            // 
            // btn_d_update
            // 
            this.btn_d_update.Location = new System.Drawing.Point(255, 35);
            this.btn_d_update.Name = "btn_d_update";
            this.btn_d_update.Size = new System.Drawing.Size(75, 30);
            this.btn_d_update.TabIndex = 4;
            this.btn_d_update.Text = "수정하기";
            this.btn_d_update.UseVisualStyleBackColor = true;
            this.btn_d_update.Click += new System.EventHandler(this.btn_d_update_Click);
            // 
            // u_d_code
            // 
            this.u_d_code.Location = new System.Drawing.Point(100, 50);
            this.u_d_code.Name = "u_d_code";
            this.u_d_code.Size = new System.Drawing.Size(140, 25);
            this.u_d_code.TabIndex = 3;
            // 
            // u_depart
            // 
            this.u_depart.Location = new System.Drawing.Point(100, 15);
            this.u_depart.Name = "u_depart";
            this.u_depart.Size = new System.Drawing.Size(140, 25);
            this.u_depart.TabIndex = 2;
            // 
            // lbl_u_d_code
            // 
            this.lbl_u_d_code.AutoSize = true;
            this.lbl_u_d_code.Location = new System.Drawing.Point(36, 50);
            this.lbl_u_d_code.Name = "lbl_u_d_code";
            this.lbl_u_d_code.Size = new System.Drawing.Size(37, 15);
            this.lbl_u_d_code.TabIndex = 1;
            this.lbl_u_d_code.Text = "코드";
            // 
            // lbl_u_depart
            // 
            this.lbl_u_depart.AutoSize = true;
            this.lbl_u_depart.Location = new System.Drawing.Point(36, 20);
            this.lbl_u_depart.Name = "lbl_u_depart";
            this.lbl_u_depart.Size = new System.Drawing.Size(52, 15);
            this.lbl_u_depart.TabIndex = 0;
            this.lbl_u_depart.Text = "부서명";
            // 
            // d_Delete
            // 
            this.d_Delete.Controls.Add(this.dd_hidden2);
            this.d_Delete.Controls.Add(this.dd_hidden);
            this.d_Delete.Controls.Add(this.btn_d_delete);
            this.d_Delete.Controls.Add(this.lvDepart_d);
            this.d_Delete.Location = new System.Drawing.Point(4, 25);
            this.d_Delete.Name = "d_Delete";
            this.d_Delete.Padding = new System.Windows.Forms.Padding(3);
            this.d_Delete.Size = new System.Drawing.Size(378, 334);
            this.d_Delete.TabIndex = 3;
            this.d_Delete.Text = "삭제";
            this.d_Delete.UseVisualStyleBackColor = true;
            // 
            // dd_hidden
            // 
            this.dd_hidden.Location = new System.Drawing.Point(9, 290);
            this.dd_hidden.Name = "dd_hidden";
            this.dd_hidden.Size = new System.Drawing.Size(100, 25);
            this.dd_hidden.TabIndex = 2;
            this.dd_hidden.Visible = false;
            // 
            // btn_d_delete
            // 
            this.btn_d_delete.Location = new System.Drawing.Point(294, 291);
            this.btn_d_delete.Name = "btn_d_delete";
            this.btn_d_delete.Size = new System.Drawing.Size(75, 30);
            this.btn_d_delete.TabIndex = 1;
            this.btn_d_delete.Text = "삭제";
            this.btn_d_delete.UseVisualStyleBackColor = true;
            this.btn_d_delete.Click += new System.EventHandler(this.btn_d_delete_Click);
            // 
            // lvDepart_d
            // 
            this.lvDepart_d.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvDepart_d_k,
            this.lvDepart_d_c});
            this.lvDepart_d.GridLines = true;
            this.lvDepart_d.Location = new System.Drawing.Point(8, 6);
            this.lvDepart_d.Name = "lvDepart_d";
            this.lvDepart_d.Size = new System.Drawing.Size(360, 270);
            this.lvDepart_d.TabIndex = 0;
            this.lvDepart_d.UseCompatibleStateImageBehavior = false;
            this.lvDepart_d.View = System.Windows.Forms.View.Details;
            this.lvDepart_d.SelectedIndexChanged += new System.EventHandler(this.lvDepart_d_SelectedIndexChanged);
            // 
            // lvDepart_d_k
            // 
            this.lvDepart_d_k.Text = "부서";
            // 
            // lvDepart_d_c
            // 
            this.lvDepart_d_c.Text = "코드";
            // 
            // ud_hidden2
            // 
            this.ud_hidden2.Location = new System.Drawing.Point(225, 296);
            this.ud_hidden2.Name = "ud_hidden2";
            this.ud_hidden2.Size = new System.Drawing.Size(100, 25);
            this.ud_hidden2.TabIndex = 7;
            this.ud_hidden2.Visible = false;
            // 
            // dd_hidden2
            // 
            this.dd_hidden2.Location = new System.Drawing.Point(141, 290);
            this.dd_hidden2.Name = "dd_hidden2";
            this.dd_hidden2.Size = new System.Drawing.Size(100, 25);
            this.dd_hidden2.TabIndex = 3;
            this.dd_hidden2.Visible = false;
            // 
            // Department
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 361);
            this.Controls.Add(this.d_tabMenu);
            this.Name = "Department";
            this.Text = "부서 관리";
            this.d_tabMenu.ResumeLayout(false);
            this.d_Search.ResumeLayout(false);
            this.d_Search.PerformLayout();
            this.d_Add.ResumeLayout(false);
            this.d_Add.PerformLayout();
            this.d_Update.ResumeLayout(false);
            this.d_Update.PerformLayout();
            this.d_Delete.ResumeLayout(false);
            this.d_Delete.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl d_tabMenu;
        private System.Windows.Forms.TabPage d_Search;
        private System.Windows.Forms.TabPage d_Add;
        private System.Windows.Forms.TabPage d_Update;
        private System.Windows.Forms.TabPage d_Delete;
        private System.Windows.Forms.ListView lvDepart_s;
        private System.Windows.Forms.Button btn_d_search;
        private System.Windows.Forms.TextBox s_depart;
        private System.Windows.Forms.Label lbl_s_depart;
        private System.Windows.Forms.ColumnHeader lvDepart_s_k;
        private System.Windows.Forms.ColumnHeader lvDepart_s_c;
        private System.Windows.Forms.ListView lvDepart_a;
        private System.Windows.Forms.Button btn_d_add;
        private System.Windows.Forms.TextBox a_d_code;
        private System.Windows.Forms.TextBox a_depart;
        private System.Windows.Forms.Label lbl_a_d_code;
        private System.Windows.Forms.Label lbl_a_depart;
        private System.Windows.Forms.ColumnHeader lvDepart_a_k;
        private System.Windows.Forms.ColumnHeader lvDepart_a_c;
        private System.Windows.Forms.ListView lvDepart_u;
        private System.Windows.Forms.ColumnHeader lvDepart_u_k;
        private System.Windows.Forms.ColumnHeader lvDepart_u_c;
        private System.Windows.Forms.Button btn_d_update;
        private System.Windows.Forms.TextBox u_d_code;
        private System.Windows.Forms.TextBox u_depart;
        private System.Windows.Forms.Label lbl_u_d_code;
        private System.Windows.Forms.Label lbl_u_depart;
        private System.Windows.Forms.Button btn_d_delete;
        private System.Windows.Forms.ListView lvDepart_d;
        private System.Windows.Forms.ColumnHeader lvDepart_d_k;
        private System.Windows.Forms.ColumnHeader lvDepart_d_c;
        private System.Windows.Forms.TextBox ud_hidden;
        private System.Windows.Forms.TextBox dd_hidden;
        private System.Windows.Forms.TextBox ud_hidden2;
        private System.Windows.Forms.TextBox dd_hidden2;
    }
}