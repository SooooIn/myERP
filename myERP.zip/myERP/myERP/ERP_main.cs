﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myERP
{
    public partial class ERP_main : Form
    {
        
        public ERP_main()
        {
            InitializeComponent();
        }

        private void aboutMyERPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Department depart = new Department();
            depart.Show();
        }

        private void 직책ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Position position = new Position();
            position.Show();
        }

        private void 종교ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Religion religion = new Religion();
            religion.Show();
        }

        private void 사원등록RToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Member mem = new Member();
            mem.Show();
        }

        private void 가족사항FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Family family = new Family();
            family.Show();
        }

        private void 퇴직자RToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Retired retired = new Retired();
            retired.Show();
        }

        private void 끝내기tCtrlXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 보고서ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report r = new Report();
            r.Show();
        }
    }
}
