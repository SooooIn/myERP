﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace myERP
{
    public partial class Department : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Department()
        {
            InitializeComponent();

            lvDepart_s.View = View.Details;
            lvDepart_s.Items.Clear();
            
            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from department order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvDepart_s.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_d_search_Click(object sender, EventArgs e)
        {
            lvDepart_s.View = View.Details;

            lvDepart_s.Items.Clear();

            string SearchValue = s_depart.ToString();
            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from department where val='" + s_depart.Text + "' order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvDepart_s.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            s_depart.Text = "";
        }

        private void btn_d_add_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "insert into department " + "values('" + a_depart.Text + "', '" + a_d_code.Text + "')";
            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            //데이터 새로고침
            lvDepart_a.View = View.Details;

            lvDepart_a.Items.Clear();

            string Aval, Acode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from department order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Aval = reader["val"].ToString();
                        Acode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Aval;
                        item.SubItems.Add(Acode);

                        this.lvDepart_a.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            a_depart.Text = "";
            a_d_code.Text = "";
        }

        private void lvDepart_u_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvDepart_u.SelectedItems.Count != 0)
            {
                int SelectRow = lvDepart_u.SelectedItems[0].Index;

                u_depart.Text = lvDepart_u.Items[SelectRow].SubItems[0].Text;
                ud_hidden2.Text = lvDepart_u.Items[SelectRow].SubItems[0].Text;
                u_d_code.Text = lvDepart_u.Items[SelectRow].SubItems[1].Text;
                ud_hidden.Text = lvDepart_u.Items[SelectRow].SubItems[1].Text;
            }
        }

        private void btn_d_update_Click(object sender, EventArgs e)
        {
            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var Conn2 = new SqlConnection(Constr);
            Conn2.Open();
            var Conn3 = new SqlConnection(Constr);
            Conn3.Open();

            var strSQL1 = "update department set val='" + u_depart.Text + "', code= '" + u_d_code.Text + "' where code='" + ud_hidden.Text + "'";
            var strSQL2 = "update member set depart='" + u_depart.Text + "' where depart='" + ud_hidden2.Text + "'";
            var strSQL3 = "update retired set depart='" + u_depart.Text + "' where depart='" + ud_hidden2.Text + "'";

            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom2.ExecuteNonQuery();
            var myCom3 = new SqlCommand(strSQL3, Conn3);
            myCom3.ExecuteNonQuery();

            Conn1.Close();
            Conn2.Close();
            Conn3.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            //데이터 새로고침
            lvDepart_u.View = View.Details;

            lvDepart_u.Items.Clear();

            string Aval, Acode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from department order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Aval = reader["val"].ToString();
                        Acode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Aval;
                        item.SubItems.Add(Acode);

                        this.lvDepart_u.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            u_depart.Text = "";
            u_d_code.Text = "";
        }

        private void d_tabMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            lvDepart_s.View = View.Details;
            lvDepart_a.View = View.Details;
            lvDepart_u.View = View.Details;
            lvDepart_d.View = View.Details;

            lvDepart_s.Items.Clear();
            lvDepart_a.Items.Clear();
            lvDepart_u.Items.Clear();
            lvDepart_d.Items.Clear();

            string Sval, Scode, Aval, Acode, Uval, Ucode, Dval, Dcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from department order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Sval = reader["val"].ToString();
                        Scode = reader["code"].ToString();
                        Aval = reader["val"].ToString();
                        Acode = reader["code"].ToString();
                        Uval = reader["val"].ToString();
                        Ucode = reader["code"].ToString();
                        Dval = reader["val"].ToString();
                        Dcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();
                        ListViewItem item1 = new ListViewItem();
                        ListViewItem item2 = new ListViewItem();
                        ListViewItem item3 = new ListViewItem();

                        item.Text = Sval;
                        item.SubItems.Add(Scode);
                        item1.Text = Aval;
                        item1.SubItems.Add(Acode);
                        item2.Text = Uval;
                        item2.SubItems.Add(Ucode);
                        item3.Text = Dval;
                        item3.SubItems.Add(Dcode);

                        this.lvDepart_s.Items.Add(item);
                        this.lvDepart_a.Items.Add(item1);
                        this.lvDepart_u.Items.Add(item2);
                        this.lvDepart_d.Items.Add(item3);
                    }
                }

                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void lvDepart_d_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvDepart_d.SelectedItems.Count != 0)
            {
                int SelectRow = lvDepart_d.SelectedItems[0].Index;

                dd_hidden2.Text = lvDepart_u.Items[SelectRow].SubItems[0].Text;
                dd_hidden.Text = lvDepart_u.Items[SelectRow].SubItems[1].Text; 
            }
        }

        private void btn_d_delete_Click(object sender, EventArgs e)
        {
            int state = 0; // 삭제 가능 상태

            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var strSQL1 = "select depart from member where depart='" + dd_hidden2.Text + "'";
            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();

            SqlDataReader reader1 = myCom1.ExecuteReader();

            while (reader1.Read())
            {
                if (reader1["depart"].ToString() == dd_hidden2.Text)
                {
                    state = 1; // 사용중인 코드로 인한 삭제 불가 상태
                }
            }

            reader1.Close();
            Conn1.Close();

            var Conn2 = new SqlConnection(Constr);
            Conn2.Open(); 
            var strSQL2 = "select depart from retired where depart='" + dd_hidden2.Text + "'";
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom2.ExecuteNonQuery();

            SqlDataReader reader2 = myCom2.ExecuteReader();

            while (reader2.Read())
            {
                if (reader2["depart"].ToString() == dd_hidden2.Text)
                {
                    state = 1; // 사용중인 코드로 인한 삭제 불가 상태
                }
            }

            reader2.Close();
            Conn2.Close();

            if(state==0)
            {
                var Conn = new SqlConnection(Constr);
                Conn.Open();

                var strSQL = "delete from department where code='" + dd_hidden.Text + "'";
                var myCom = new SqlCommand(strSQL, Conn);
                myCom.ExecuteNonQuery();

                Conn.Close();
                MessageBox.Show("데이터가 삭제되었습니다.", "알림");
            }
            else if(state==1)
            {
                MessageBox.Show("사용 중인 코드입니다.", "알림");
            }
                

            //데이터 새로고침
            lvDepart_d.View = View.Details;

            lvDepart_d.Items.Clear();

            string Aval, Acode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from department order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Aval = reader["val"].ToString();
                        Acode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Aval;
                        item.SubItems.Add(Acode);

                        this.lvDepart_d.Items.Add(item);
                    }
                }

                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }
    }
}
