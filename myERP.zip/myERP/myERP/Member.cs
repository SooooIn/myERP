﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myERP
{
    public partial class Member : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Member()
        {
            InitializeComponent();

            cb_section.SelectedIndex = 0;

            lvMember.View = View.Details;
            lvMember.Items.Clear();

            string id, name, sex, position, depart, email;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from member where work=1";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();
                        sex = reader["sex"].ToString();
                        position = reader["depart"].ToString();
                        depart = reader["position"].ToString();
                        email = reader["e_mail"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);
                        item.SubItems.Add(sex);
                        item.SubItems.Add(position);
                        item.SubItems.Add(depart);
                        item.SubItems.Add(email);

                        this.lvMember.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void textClear()
        {
            tb_id.Text = "";
            tb_name_k.Text = "";
            tb_name_e.Text = "";
            tb_name_c.Text = "";
            tb_address.Text = "";
            tb_height.Text = "";
            tb_weight.Text = "";
            tb_email.Text = "";
            tb_sight_l.Text = "";
            tb_sight_r.Text = "";
            tb_call.Text = "";
            rb_male.Checked = true;
            rb_married.Checked = true;
        }

        private void new_show() // 변경된 정보 적용 후 새로 고침
        {
            lvMember.View = View.Details;
            lvMember.Items.Clear();

            string id, name, gender, position, depart, email;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                String Sql = "Select * from member where work=1 order by id asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();
                        gender = reader["sex"].ToString();
                        position = reader["position"].ToString();
                        depart = reader["depart"].ToString();
                        email = reader["e_mail"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);
                        item.SubItems.Add(gender);
                        item.SubItems.Add(position);
                        item.SubItems.Add(depart);
                        item.SubItems.Add(email);

                        this.lvMember.Items.Add(item);
                    }
                }

                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void Member_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String depart_Sql = "Select val from department order by val asc";

                SqlCommand d_dbcmd = new SqlCommand(depart_Sql, dbcon);
                SqlDataReader d_reader = d_dbcmd.ExecuteReader();

                if (d_reader.HasRows)
                {
                    while (d_reader.Read())
                    {                  
                        this.cb_depart.Items.Add(d_reader["val"].ToString());                   
                    }
                }
                d_reader.Close();              
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
          
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String position_Sql = "Select val from position order by val asc";

                SqlCommand p_dbcmd = new SqlCommand(position_Sql, dbcon);
                SqlDataReader p_reader = p_dbcmd.ExecuteReader();

                if (p_reader.HasRows)
                {
                    while (p_reader.Read())
                    {
                        this.cb_position.Items.Add(p_reader["val"].ToString());
                    }
                }
                p_reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String religion_Sql = "Select val from religion order by val asc";

                SqlCommand r_dbcmd = new SqlCommand(religion_Sql, dbcon);
                SqlDataReader r_reader = r_dbcmd.ExecuteReader();

                if (r_reader.HasRows)
                {
                    while (r_reader.Read())
                    {
                        this.cb_religion.Items.Add(r_reader["val"].ToString());

                    }
                }
                r_reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }           
        }

        private void btn_m_insert_Click(object sender, EventArgs e)
        {
            try
            {
                var Conn = new SqlConnection(Constr);
                Conn.Open();

                var strSQL = "insert into member values ('"
                              + tb_name_k.Text + "', '"
                              + tb_name_e.Text + "', '"
                              + tb_name_c.Text + "', '"
                              + tb_address.Text + "', "
                              + (this.rb_married.Checked == true ? 1 : 0) + ",'"
                              + tb_email.Text + "', '"
                              + tb_call.Text + "', "
                              + (this.rb_male.Checked == true ? 0 : 1) + ","
                              + int.Parse(tb_height.Text) + ", "
                              + int.Parse(tb_weight.Text) + ", '"
                              + cb_blood.Text + "', '"
                              + tb_sight_l.Text + "', '"
                              + tb_sight_r.Text + "', '"
                              + cb_religion.Text + "', '"
                              + cb_depart.Text + "', '"
                              + cb_position.Text + "', '"
                              + dtp_birth_date.Text + "', '"
                              + dtp_join_date.Text + "', '"
                              + tb_id.Text + "', "
                              + 1 + ")";

                var myCom = new SqlCommand(strSQL, Conn);
                myCom.ExecuteNonQuery();

                Conn.Close();
                MessageBox.Show("데이터가 저장되었습니다.", "알림");

                new_show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("등록 불가", "오류!");
            }

            textClear();
        }

        private void lvMember_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvMember.SelectedItems.Count != 0)
            {
                int SelectRow = lvMember.SelectedItems[0].Index;
                
                s_id.Text = lvMember.Items[SelectRow].SubItems[0].Text;

                var strSQL = "select * from member where id='" + s_id.Text + "' and work=1"; 

                try
                {
                    SqlConnection dbcon = new SqlConnection();
                    dbcon.ConnectionString = Constr;

                    SqlCommand dbcmd = new SqlCommand(strSQL, dbcon);

                    dbcon.Open();

                    SqlDataReader reader = dbcmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            tb_id.Text = reader["id"].ToString();
                            tb_name_k.Text = reader["name_k"].ToString();
                            tb_name_e.Text= reader["name_e"].ToString();
                            tb_name_c.Text= reader["name_c"].ToString();
                            tb_address.Text= reader["m_address"].ToString();
                            if(reader["marriage"].ToString()=="0") { rb_unmarried.Checked = true; }
                            else { rb_married.Checked = true; }
                            tb_email.Text = reader["e_mail"].ToString();
                            tb_call.Text = reader["c_number"].ToString();
                            if(reader["sex"].ToString()=="0") { rb_male.Checked = true; }
                            else { rb_female.Checked = true; }
                            tb_height.Text = reader["height"].ToString();
                            tb_weight.Text = reader["weight_"].ToString();
                            cb_blood.Text = reader["blood"].ToString();
                            tb_sight_l.Text = reader["sight_l"].ToString();
                            tb_sight_r.Text = reader["sight_r"].ToString();
                            int idx_r = cb_religion.FindString(reader["religion"].ToString());
                            cb_religion.SelectedIndex = idx_r;
                            int idx_d = cb_depart.FindString(reader["depart"].ToString());
                            cb_depart.SelectedIndex = idx_d;
                            int idx_p = cb_position.FindString(reader["position"].ToString());
                            cb_position.SelectedIndex = idx_p;
                            dtp_birth_date.Text = reader["birth_date"].ToString();
                            dtp_join_date.Text = reader["join_date"].ToString();
                            tb_id.Text = reader["id"].ToString();
                        }
                    }
                    reader.Close();
                    dbcon.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "오류!");
                }
            }
        }

        private void btn_m_update_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "update member set name_k='"
                          + tb_name_k.Text + "', name_e='"
                          + tb_name_e.Text + "', name_c='"
                          + tb_name_c.Text + "', m_address='"
                          + tb_address.Text + "', marriage="
                          + (this.rb_married.Checked == true ? 1 : 0) + ", e_mail='"
                          + tb_email.Text + "', c_number='"
                          + tb_call.Text + "', sex="
                          + (this.rb_male.Checked == true ? 0 : 1) + ", height="
                          + int.Parse(tb_height.Text) + ", weight_="
                          + int.Parse(tb_weight.Text) + ", blood='"
                          + cb_blood.Text + "', sight_l='"
                          + tb_sight_l.Text + "', sight_r='"
                          + tb_sight_r.Text + "', religion='"
                          + cb_religion.Text + "', depart='"
                          + cb_depart.Text + "', position='"
                          + cb_position.Text + "', birth_date='"
                          + dtp_birth_date.Text + "', join_date='"
                          + dtp_join_date.Text + "', work=1 where id='" + s_id.Text + "'";

            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            new_show();
            textClear();
        }

        private void btn_m_delete_Click(object sender, EventArgs e)
        {
            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var Conn2 = new SqlConnection(Constr);
            Conn2.Open();

            var strSQL1 = "delete from member where id='" + s_id.Text + "'";
            var strSQL2 = "delete from family where f_id='" + s_id.Text + "'";

            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom2.ExecuteNonQuery();

            Conn1.Close();
            Conn2.Close();
            MessageBox.Show("데이터가 삭제되었습니다.", "알림");

            new_show();
            textClear();
        }

        private void cb_section_SelectedIndexChanged(object sender, EventArgs e)
        {
            hidden_s.Text = cb_section.SelectedIndex.ToString(); 
        }

        private void btn_m_search_Click(object sender, EventArgs e)
        {
            lvMember.View = View.Details;

            lvMember.Items.Clear();

            string id, name, gender, position, depart, email;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;

                String Sql;
                string sql1 = "Select * from member where id= '" + tb_search.Text + "' and work=1 order by id asc";
                string sql2 = "Select * from member where name_k= '" + tb_search.Text + "' and work=1 order by id asc";
                string sql3 = "Select * from member where depart= '" + tb_search.Text + "' and work=1 order by id asc";
                string sql4 = "Select * from member where depart= '" + tb_search.Text + "' and work=1 order by id asc";

                if (int.Parse(hidden_s.Text) == 0) { Sql = sql1; }
                else if (int.Parse(hidden_s.Text) == 1) { Sql = sql2; }
                else { Sql = sql3; }

                if (String.IsNullOrEmpty(tb_search.Text)) { Sql = sql4; }

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();
                        gender = reader["sex"].ToString();
                        position = reader["position"].ToString();
                        depart = reader["depart"].ToString();
                        email = reader["e_mail"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);
                        item.SubItems.Add(gender);
                        item.SubItems.Add(position);
                        item.SubItems.Add(depart);
                        item.SubItems.Add(email);

                        this.lvMember.Items.Add(item);
                    }
                }

                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            textClear();
        }
    }
}
