﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myERP
{
    public partial class Family : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Family()
        {
            InitializeComponent();
        }

        private void textClear()
        {
            tb_f_id2.Text = "";
            tb_f_name.Text = "";
            tb_f_depart.Text = "";
            tb_f_position.Text = "";
            tb_f_relation.Text = "";
            tb_f_name2.Text = "";
            tb_f_place.Text = "";
            tb_f_job.Text = "";
            tb_f_number.Text = "";
        }

        private void new_show()
        {
            lvFamily.View = View.Details;

            lvFamily.Items.Clear();

            string relation, f_name, birth_date, job, place, c_number;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from family where f_id='" + cb_f_id.Text + "'";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        relation = reader["relation"].ToString();
                        f_name = reader["f_name"].ToString();
                        birth_date = reader["birth_date"].ToString();
                        job = reader["job"].ToString();
                        place = reader["place"].ToString();
                        c_number = reader["c_number"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = relation;

                        item.SubItems.Add(f_name);
                        item.SubItems.Add(birth_date);
                        item.SubItems.Add(job);
                        item.SubItems.Add(place);
                        item.SubItems.Add(c_number);

                        this.lvFamily.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_f_search_Click(object sender, EventArgs e)
        {
            lvFamily.View = View.Details;
            lvFamily.Items.Clear();

            string relation, f_name, birth_date, job, place, c_number;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from family as f right outer join member as m on f.f_id=m.id where m.id='" + cb_f_id.Text + "'";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        tb_f_id2.Text = reader["id"].ToString();
                        tb_f_name.Text = reader["name_k"].ToString();
                        tb_f_depart.Text = reader["depart"].ToString();
                        tb_f_position.Text = reader["position"].ToString();
                            
                        relation = reader["relation"].ToString();
                        f_name = reader["f_name"].ToString();
                        birth_date = reader["birth_date"].ToString();
                        job = reader["job"].ToString();
                        place = reader["place"].ToString();
                        c_number = reader["c_number"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = relation;
                        item.SubItems.Add(f_name);
                        item.SubItems.Add(birth_date);
                        item.SubItems.Add(job);
                        item.SubItems.Add(place);
                        item.SubItems.Add(c_number);

                        this.lvFamily.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void Family_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select id from member where work=1 order by id asc";

                SqlCommand d_dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader d_reader = d_dbcmd.ExecuteReader();

                if (d_reader.HasRows)
                {
                    while (d_reader.Read())
                    {
                        this.cb_f_id.Items.Add(d_reader["id"].ToString());
                    }
                }
                d_reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void lvFamily_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvFamily.SelectedItems.Count != 0)
            {
                int SelectRow = lvFamily.SelectedItems[0].Index;

                tb_f_relation.Text = lvFamily.Items[SelectRow].SubItems[0].Text;
                tb_f_name2.Text = lvFamily.Items[SelectRow].SubItems[1].Text;
                dtp_f_birth.Text = lvFamily.Items[SelectRow].SubItems[2].Text;
                tb_f_job.Text = lvFamily.Items[SelectRow].SubItems[3].Text;
                tb_f_place.Text = lvFamily.Items[SelectRow].SubItems[4].Text;
                tb_f_number.Text = lvFamily.Items[SelectRow].SubItems[5].Text;
                call_hidden.Text = lvFamily.Items[SelectRow].SubItems[5].Text;
            }
        }

        private void btn_f_insert_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "insert into family values('"
                            + cb_f_id.Text + "', '"
                            + tb_f_relation.Text + "', '"
                            + tb_f_place.Text + "', '"
                            + tb_f_name2.Text + "', '"
                            + tb_f_job.Text + "', '"
                            + dtp_f_birth.Text + "', '"
                            + tb_f_number.Text + "'"
                            + ")";

            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            new_show();
            textClear();
        }

        private void btn_f_update_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "update family set relation='"
                                    + tb_f_relation.Text + "', place='"
                                    + tb_f_place.Text + "', f_name='"
                                    + tb_f_name2.Text + "', job='"
                                    + tb_f_job.Text + "', birth_date='"
                                    + dtp_f_birth.Text + "', c_number='"
                                    + tb_f_number.Text + "' where f_id='" + cb_f_id.Text + "'and c_number='" + call_hidden.Text + "'";
            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 변경되었습니다.", "알림");

            new_show();
            textClear();
        }

        private void btn_f_delete_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "delete from family where f_id='" + cb_f_id.Text + "'and c_number='" + call_hidden.Text + "'";
            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 삭제되었습니다.", "알림");

            new_show();
            textClear();
        }
    }
}
