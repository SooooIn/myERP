﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myERP
{
    public partial class Report : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Report()
        {
            InitializeComponent();

            this.rb_total.Checked = true;        
        }

        private void rb_total_CheckedChanged(object sender, EventArgs e)
        {
            // listview
            lv_Report.Clear();

            ColumnHeader col_id = new ColumnHeader();   //객체 선언 
            ColumnHeader col_name = new ColumnHeader();
            ColumnHeader col_depart = new ColumnHeader();
            ColumnHeader col_position = new ColumnHeader();
            ColumnHeader col_jDate = new ColumnHeader();
            ColumnHeader col_bDate = new ColumnHeader();

            col_id.Text = "사번";   //열 제목 표시
            col_name.Text = "성명";
            col_depart.Text = "부서";
            col_position.Text = "직위";
            col_jDate.Text = "입사일자";
            col_bDate.Text = "생년월일";

            lv_Report.Columns.Add(col_id);   //열 추가 실행
            lv_Report.Columns.Add(col_name);
            lv_Report.Columns.Add(col_depart);
            lv_Report.Columns.Add(col_position);
            lv_Report.Columns.Add(col_jDate);
            lv_Report.Columns.Add(col_bDate);

            lv_Report.Columns[0].Width = 100;
            lv_Report.Columns[1].Width = 90;
            lv_Report.Columns[2].Width = 90;
            lv_Report.Columns[3].Width = 90;
            lv_Report.Columns[4].Width = 170;
            lv_Report.Columns[5].Width = 170;

        }

        private void rb_reason_CheckedChanged(object sender, EventArgs e)
        {
            // listview
            lv_Report.Clear();

            ColumnHeader col_id = new ColumnHeader();   //객체 선언 
            ColumnHeader col_name = new ColumnHeader();
            ColumnHeader col_depart = new ColumnHeader();
            ColumnHeader col_position = new ColumnHeader();
            ColumnHeader col_rDate = new ColumnHeader();

            col_id.Text = "사번";   //열 제목 표시
            col_name.Text = "성명";
            col_depart.Text = "부서";
            col_position.Text = "직위";
            col_rDate.Text = "퇴사일자";

            lv_Report.Columns.Add(col_id);   //열 추가 실행
            lv_Report.Columns.Add(col_name);
            lv_Report.Columns.Add(col_depart);
            lv_Report.Columns.Add(col_position);
            lv_Report.Columns.Add(col_rDate);

            lv_Report.Columns[0].Width = 100;
            lv_Report.Columns[1].Width = 90;
            lv_Report.Columns[2].Width = 90;
            lv_Report.Columns[3].Width = 90;
            lv_Report.Columns[4].Width = 170;


            // combobox
            cb_report.Items.Clear();

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from retirement_reason";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cb_report.Items.Add(reader["val"].ToString());
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void rb_depart_CheckedChanged(object sender, EventArgs e)
        {
            // listview
            lv_Report.Clear();

            ColumnHeader col_id = new ColumnHeader();   //객체 선언 
            ColumnHeader col_name = new ColumnHeader();
            ColumnHeader col_position = new ColumnHeader();
            ColumnHeader col_jDate = new ColumnHeader();
            ColumnHeader col_bDate = new ColumnHeader();

            col_id.Text = "사번";   //열 제목 표시
            col_name.Text = "성명";
            col_position.Text = "직위";
            col_jDate.Text = "입사일자";
            col_bDate.Text = "생년월일";

            lv_Report.Columns.Add(col_id);   //열 추가 실행
            lv_Report.Columns.Add(col_name);
            lv_Report.Columns.Add(col_position);
            lv_Report.Columns.Add(col_jDate);
            lv_Report.Columns.Add(col_bDate);

            lv_Report.Columns[0].Width = 100;
            lv_Report.Columns[1].Width = 90;
            lv_Report.Columns[2].Width = 90;
            lv_Report.Columns[3].Width = 170;
            lv_Report.Columns[4].Width = 170;


            // combobox
            cb_report.Items.Clear();

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from department";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cb_report.Items.Add(reader["val"].ToString());
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void rb_position_CheckedChanged(object sender, EventArgs e)
        {
            // listview
            lv_Report.Clear();

            ColumnHeader col_id = new ColumnHeader();   //객체 선언 
            ColumnHeader col_name = new ColumnHeader();
            ColumnHeader col_depart = new ColumnHeader();
            ColumnHeader col_jDate = new ColumnHeader();
            ColumnHeader col_bDate = new ColumnHeader();

            col_id.Text = "사번";   //열 제목 표시
            col_name.Text = "성명";
            col_depart.Text = "부서";
            col_jDate.Text = "입사일자";
            col_bDate.Text = "생년월일";

            lv_Report.Columns.Add(col_id);   //열 추가 실행
            lv_Report.Columns.Add(col_name);
            lv_Report.Columns.Add(col_depart);
            lv_Report.Columns.Add(col_jDate);
            lv_Report.Columns.Add(col_bDate);

            lv_Report.Columns[0].Width = 100;
            lv_Report.Columns[1].Width = 90;
            lv_Report.Columns[2].Width = 90;
            lv_Report.Columns[3].Width = 170;
            lv_Report.Columns[4].Width = 170;


            // combobox
            cb_report.Items.Clear();

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from position";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cb_report.Items.Add(reader["val"].ToString());
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_report_Click(object sender, EventArgs e)
        {
            lv_Report.View = View.Details;

            lv_Report.Items.Clear();

            if (rb_total.Checked==true)
            {
                try
                {
                    SqlConnection dbcon = new SqlConnection();
                    dbcon.ConnectionString = Constr;
                    dbcon.Open();

                    String Sql = "Select * from member where work = 1 order by id asc";
                    String id, name, depart, position, jDate, bDate;

                    SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                    SqlDataReader reader = dbcmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            id = reader["id"].ToString();
                            name = reader["name_k"].ToString();
                            depart = reader["depart"].ToString();
                            position = reader["position"].ToString();
                            jDate = reader["join_date"].ToString();
                            bDate = reader["birth_date"].ToString();

                            ListViewItem item = new ListViewItem();

                            item.Text = id;
                            item.SubItems.Add(name);
                            item.SubItems.Add(depart);
                            item.SubItems.Add(position);
                            item.SubItems.Add(jDate);
                            item.SubItems.Add(bDate);

                            this.lv_Report.Items.Add(item);
                        }
                    }
                    reader.Close();
                    dbcon.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "오류!");
                }
            }
            else if(rb_reason.Checked==true)
            {
                try
                {
                    SqlConnection dbcon = new SqlConnection();
                    dbcon.ConnectionString = Constr;
                    dbcon.Open();

                    String Sql = "Select member.id, member.name_k, member.depart, member.position, retired.retire_date" +
                        " from member inner join retired on member.id=retired.id where work = 0 and retired.r_reason='"
                        + cb_report.Text + "' order by id asc";
                    String id, name, depart, position, rDate;

                    SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                    SqlDataReader reader = dbcmd.ExecuteReader();
                    
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            id = reader["id"].ToString();
                            name = reader["name_k"].ToString();
                            depart = reader["depart"].ToString();
                            position = reader["position"].ToString();
                            rDate = reader["retire_date"].ToString();

                            ListViewItem item = new ListViewItem();

                            item.Text = id;
                            item.SubItems.Add(name);
                            item.SubItems.Add(depart);
                            item.SubItems.Add(position);
                            item.SubItems.Add(rDate);

                            this.lv_Report.Items.Add(item);
                        }
                    }
                    reader.Close();
                    dbcon.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "오류!");
                }
            }
            else if(rb_depart.Checked==true)
            {
                try
                {
                    SqlConnection dbcon = new SqlConnection();
                    dbcon.ConnectionString = Constr;
                    dbcon.Open();

                    String Sql = "Select * from member where work = 1 and depart='" + cb_report.Text + "' order by id asc";
                    String id, name, position, jDate, bDate;

                    SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                    SqlDataReader reader = dbcmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            id = reader["id"].ToString();
                            name = reader["name_k"].ToString();
                            position = reader["position"].ToString();
                            jDate = reader["join_date"].ToString();
                            bDate = reader["birth_date"].ToString();

                            ListViewItem item = new ListViewItem();

                            item.Text = id;
                            item.SubItems.Add(name);
                            item.SubItems.Add(position);
                            item.SubItems.Add(jDate);
                            item.SubItems.Add(bDate);

                            this.lv_Report.Items.Add(item);
                        }
                    }
                    reader.Close();
                    dbcon.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "오류!");
                }
            }
            else if(rb_position.Checked==true)
            {
                try
                {
                    SqlConnection dbcon = new SqlConnection();
                    dbcon.ConnectionString = Constr;
                    dbcon.Open();

                    String Sql = "Select * from member where work = 1 and position='" + cb_report.Text + "' order by id asc";
                    String id, name, depart, jDate, bDate;

                    SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                    SqlDataReader reader = dbcmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            id = reader["id"].ToString();
                            name = reader["name_k"].ToString();
                            depart = reader["depart"].ToString();
                            jDate = reader["join_date"].ToString();
                            bDate = reader["birth_date"].ToString();

                            ListViewItem item = new ListViewItem();

                            item.Text = id;
                            item.SubItems.Add(name);
                            item.SubItems.Add(depart);
                            item.SubItems.Add(jDate);
                            item.SubItems.Add(bDate);

                            this.lv_Report.Items.Add(item);
                        }
                    }
                    reader.Close();
                    dbcon.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "오류!");
                }
            }  
        }
    }
}
