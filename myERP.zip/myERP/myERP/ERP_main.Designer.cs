﻿namespace myERP
{
    partial class ERP_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.끝내기tCtrlXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMyERPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.직책ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.종교ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사원등록RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.가족사항FToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.퇴직자RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.보고서ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.도움말HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myERP에대하여ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.사원등록RToolStripMenuItem,
            this.가족사항FToolStripMenuItem,
            this.퇴직자RToolStripMenuItem,
            this.보고서ToolStripMenuItem,
            this.도움말HToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1102, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.끝내기tCtrlXToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.fileToolStripMenuItem.Text = "파일(&F)";
            // 
            // 끝내기tCtrlXToolStripMenuItem
            // 
            this.끝내기tCtrlXToolStripMenuItem.Name = "끝내기tCtrlXToolStripMenuItem";
            this.끝내기tCtrlXToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.끝내기tCtrlXToolStripMenuItem.Text = "끝내기(&x)";
            this.끝내기tCtrlXToolStripMenuItem.Click += new System.EventHandler(this.끝내기tCtrlXToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutMyERPToolStripMenuItem,
            this.직책ToolStripMenuItem,
            this.종교ToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(125, 24);
            this.helpToolStripMenuItem.Text = "기초정보관리(&I)";
            // 
            // aboutMyERPToolStripMenuItem
            // 
            this.aboutMyERPToolStripMenuItem.Name = "aboutMyERPToolStripMenuItem";
            this.aboutMyERPToolStripMenuItem.Size = new System.Drawing.Size(114, 26);
            this.aboutMyERPToolStripMenuItem.Text = "부서";
            this.aboutMyERPToolStripMenuItem.Click += new System.EventHandler(this.aboutMyERPToolStripMenuItem_Click);
            // 
            // 직책ToolStripMenuItem
            // 
            this.직책ToolStripMenuItem.Name = "직책ToolStripMenuItem";
            this.직책ToolStripMenuItem.Size = new System.Drawing.Size(114, 26);
            this.직책ToolStripMenuItem.Text = "직책";
            this.직책ToolStripMenuItem.Click += new System.EventHandler(this.직책ToolStripMenuItem_Click);
            // 
            // 종교ToolStripMenuItem
            // 
            this.종교ToolStripMenuItem.Name = "종교ToolStripMenuItem";
            this.종교ToolStripMenuItem.Size = new System.Drawing.Size(114, 26);
            this.종교ToolStripMenuItem.Text = "종교";
            this.종교ToolStripMenuItem.Click += new System.EventHandler(this.종교ToolStripMenuItem_Click);
            // 
            // 사원등록RToolStripMenuItem
            // 
            this.사원등록RToolStripMenuItem.Name = "사원등록RToolStripMenuItem";
            this.사원등록RToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.사원등록RToolStripMenuItem.Text = "사원관리(&A)";
            this.사원등록RToolStripMenuItem.Click += new System.EventHandler(this.사원등록RToolStripMenuItem_Click);
            // 
            // 가족사항FToolStripMenuItem
            // 
            this.가족사항FToolStripMenuItem.Name = "가족사항FToolStripMenuItem";
            this.가족사항FToolStripMenuItem.Size = new System.Drawing.Size(98, 24);
            this.가족사항FToolStripMenuItem.Text = "가족사항(&F)";
            this.가족사항FToolStripMenuItem.Click += new System.EventHandler(this.가족사항FToolStripMenuItem_Click);
            // 
            // 퇴직자RToolStripMenuItem
            // 
            this.퇴직자RToolStripMenuItem.Name = "퇴직자RToolStripMenuItem";
            this.퇴직자RToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.퇴직자RToolStripMenuItem.Text = "퇴직자(&R)";
            this.퇴직자RToolStripMenuItem.Click += new System.EventHandler(this.퇴직자RToolStripMenuItem_Click);
            // 
            // 보고서ToolStripMenuItem
            // 
            this.보고서ToolStripMenuItem.Name = "보고서ToolStripMenuItem";
            this.보고서ToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.보고서ToolStripMenuItem.Text = "보고서(&P)";
            this.보고서ToolStripMenuItem.Click += new System.EventHandler(this.보고서ToolStripMenuItem_Click);
            // 
            // 도움말HToolStripMenuItem
            // 
            this.도움말HToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myERP에대하여ToolStripMenuItem});
            this.도움말HToolStripMenuItem.Name = "도움말HToolStripMenuItem";
            this.도움말HToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.도움말HToolStripMenuItem.Text = "도움말(&H)";
            // 
            // myERP에대하여ToolStripMenuItem
            // 
            this.myERP에대하여ToolStripMenuItem.Name = "myERP에대하여ToolStripMenuItem";
            this.myERP에대하여ToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.myERP에대하여ToolStripMenuItem.Text = "myERP에 대하여...";
            // 
            // ERP_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ERP_main";
            this.Text = "myERP";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutMyERPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 직책ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 종교ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사원등록RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 가족사항FToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 퇴직자RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 보고서ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도움말HToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myERP에대하여ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 끝내기tCtrlXToolStripMenuItem;
    }
}