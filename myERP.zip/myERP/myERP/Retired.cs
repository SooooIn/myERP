﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myERP
{
    public partial class Retired : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Retired()
        {
            InitializeComponent();

            rb_S_reason.Checked = true;
        }

        private void textClear()
        {
            tb_AU_name.Text = "";
            tb_AU_call.Text = "";
        }

        private void radio_state() // 라디오 버튼 상태에 따른 sql문 적용 후 정렬
        {
            String Sql= "Select * from retired order by";

            if (rb_S_reason.Checked==true) { Sql += " r_reason asc"; }
            else if(rb_S_depart.Checked==true) { Sql += " depart asc"; }
            else if(rb_S_date.Checked==true) { Sql += " retire_date asc";  }
            else if(rb_S_position.Checked==true) { Sql += " position asc"; }

            lvRetired.View = View.Details;
            lvRetired.Items.Clear();

            string id, name, call, depart, position, date, reason;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["r_name"].ToString();
                        call = reader["c_number"].ToString();
                        depart = reader["depart"].ToString();
                        position = reader["position"].ToString();
                        date = reader["retire_date"].ToString();
                        reason = reader["r_reason"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);
                        item.SubItems.Add(call);
                        item.SubItems.Add(depart);
                        item.SubItems.Add(position);
                        item.SubItems.Add(date);
                        item.SubItems.Add(reason);

                        this.lvRetired.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void new_show() // lv_served, lv_retired listview 새로고침
        {
            lv_served.View = View.Details;
            lv_retired.View = View.Details;

            lv_served.Items.Clear();
            lv_retired.Items.Clear();

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from member where work=1 order by id asc";
                String id, name;

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);

                        this.lv_served.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from member where work=0 order by id asc";
                String id, name;

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);

                        this.lv_retired.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }
        private void Retired_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from member where work=1 order by id asc";
                String id, name;

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);

                        this.lv_served.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from member where work=0 order by id asc";
                String id, name;

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["id"].ToString();
                        name = reader["name_k"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = id;
                        item.SubItems.Add(name);

                        this.lv_retired.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String depart_Sql = "Select val from department order by val asc";

                SqlCommand d_dbcmd = new SqlCommand(depart_Sql, dbcon);
                SqlDataReader d_reader = d_dbcmd.ExecuteReader();

                if (d_reader.HasRows)
                {
                    while (d_reader.Read())
                    {
                        this.cb_AU_depart.Items.Add(d_reader["val"].ToString());
                    }
                }
                d_reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String position_Sql = "Select val from position order by val asc";

                SqlCommand p_dbcmd = new SqlCommand(position_Sql, dbcon);
                SqlDataReader p_reader = p_dbcmd.ExecuteReader();

                if (p_reader.HasRows)
                {
                    while (p_reader.Read())
                    {
                        this.cb_AU_position.Items.Add(p_reader["val"].ToString());
                    }
                }
                p_reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String religion_Sql = "Select val from retirement_reason order by val asc";

                SqlCommand r_dbcmd = new SqlCommand(religion_Sql, dbcon);
                SqlDataReader r_reader = r_dbcmd.ExecuteReader();

                if (r_reader.HasRows)
                {
                    while (r_reader.Read())
                    {
                        this.cb_AU_reason.Items.Add(r_reader["val"].ToString());
                    }
                }
                r_reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_r_search_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from member where id='" + cb_r_id.Text + "'";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cb_r_id.Text = reader["id"].ToString();
                        tb_AU_name.Text = reader["name_k"].ToString();
                        tb_AU_call.Text = reader["c_number"].ToString();
                        int idx_d = cb_AU_depart.FindString(reader["depart"].ToString());
                        cb_AU_depart.SelectedIndex = idx_d;
                        int idx_p = cb_AU_position.FindString(reader["position"].ToString());
                        cb_AU_position.SelectedIndex = idx_p;
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from retired where id='" + cb_r_id.Text + "'";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dtp_AU_date.Text = reader["retire_date"].ToString();
                        int idx_r = cb_AU_reason.FindString(reader["r_reason"].ToString());
                        cb_AU_reason.SelectedIndex = idx_r;
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_AU_add_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "insert into retired values('"
                            + cb_r_id.Text + "', '"
                            + tb_AU_name.Text + "', '"
                            + tb_AU_call.Text + "', '"
                            + cb_AU_depart.Text + "', '"
                            + cb_AU_position.Text + "', '"
                            + dtp_AU_date.Text + "', '"
                            + cb_AU_reason.Text + "'"
                            + ")";

            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            textClear();
        }

        private void btn_AU_update_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "update retired set retire_date='"
                            + dtp_AU_date.Text + "', r_reason='"
                            + cb_AU_reason.Text + "' where id='" + cb_r_id.Text + "'";

            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 수정되었습니다.", "알림");

            textClear();
        }

        private void rb_S_reason_CheckedChanged(object sender, EventArgs e)
        {
            radio_state();
        }

        private void rb_S_depart_CheckedChanged(object sender, EventArgs e)
        {
            radio_state();
        }

        private void rb_S_date_CheckedChanged(object sender, EventArgs e)
        {
            radio_state();
        }

        private void rb_S_position_CheckedChanged(object sender, EventArgs e)
        {
            radio_state();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "update member set work=0 where id='" + retire_hidden.Text + "'";

            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();

            new_show();

            MessageBox.Show("세부 사항을 입력하세요!", "알림");
        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            var Conn2 = new SqlConnection(Constr);
            Conn.Open();
            Conn2.Open();

            var strSQL = "update member set work=1 where id='" + retire_hidden.Text + "'";
            var strSQL2 = "delete from retired where id='" + retire_hidden.Text + "'";

            var myCom = new SqlCommand(strSQL, Conn);
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom.ExecuteNonQuery();
            myCom2.ExecuteNonQuery();

            Conn.Close();
            Conn2.Close();

            new_show();
        }

        private void lv_served_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lv_served.SelectedItems.Count != 0)
            {
                int SelectRow = lv_served.SelectedItems[0].Index;

                retire_hidden.Text = lv_served.Items[SelectRow].SubItems[0].Text;
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_r_id.Items.Clear();

            radio_state();

            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = Constr;
                dbcon.Open();

                String Sql = "Select * from member where work=0 order by id asc";

                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);
                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        this.cb_r_id.Items.Add(reader["id"].ToString());
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void lv_retired_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lv_retired.SelectedItems.Count != 0)
            {
                int SelectRow = lv_retired.SelectedItems[0].Index;

                retire_hidden.Text = lv_retired.Items[SelectRow].SubItems[0].Text;
            }
        }
    }
}
