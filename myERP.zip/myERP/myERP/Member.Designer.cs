﻿namespace myERP
{
    partial class Member
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_section = new System.Windows.Forms.Label();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.btn_m_search = new System.Windows.Forms.Button();
            this.cb_section = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.tb_call = new System.Windows.Forms.TextBox();
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_position = new System.Windows.Forms.Label();
            this.lbl_join_date = new System.Windows.Forms.Label();
            this.lbl_birth_date = new System.Windows.Forms.Label();
            this.cb_religion = new System.Windows.Forms.ComboBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_depart = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.tb_name_c = new System.Windows.Forms.TextBox();
            this.lbl_call = new System.Windows.Forms.Label();
            this.tb_name_k = new System.Windows.Forms.TextBox();
            this.cb_depart = new System.Windows.Forms.ComboBox();
            this.lbl_marriage = new System.Windows.Forms.Label();
            this.tb_name_e = new System.Windows.Forms.TextBox();
            this.lbl_religion = new System.Windows.Forms.Label();
            this.cb_position = new System.Windows.Forms.ComboBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.dtp_birth_date = new System.Windows.Forms.DateTimePicker();
            this.dtp_join_date = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb_unmarried = new System.Windows.Forms.RadioButton();
            this.rb_married = new System.Windows.Forms.RadioButton();
            this.lbl_sex = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_sight = new System.Windows.Forms.Label();
            this.tb_height = new System.Windows.Forms.TextBox();
            this.tb_sight_l = new System.Windows.Forms.TextBox();
            this.lvMember = new System.Windows.Forms.ListView();
            this.col_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_sex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_position = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_depart = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tb_address = new System.Windows.Forms.TextBox();
            this.rb_male = new System.Windows.Forms.RadioButton();
            this.rb_female = new System.Windows.Forms.RadioButton();
            this.cb_blood = new System.Windows.Forms.ComboBox();
            this.tb_weight = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lbl_weight = new System.Windows.Forms.Label();
            this.lbl_height = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tb_sight_r = new System.Windows.Forms.TextBox();
            this.s_id = new System.Windows.Forms.TextBox();
            this.hidden_s = new System.Windows.Forms.TextBox();
            this.btn_m_insert = new System.Windows.Forms.Button();
            this.btn_m_update = new System.Windows.Forms.Button();
            this.btn_m_delete = new System.Windows.Forms.Button();
            this.tableLayoutPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_section
            // 
            this.lbl_section.AutoSize = true;
            this.lbl_section.Location = new System.Drawing.Point(19, 20);
            this.lbl_section.Name = "lbl_section";
            this.lbl_section.Size = new System.Drawing.Size(37, 15);
            this.lbl_section.TabIndex = 0;
            this.lbl_section.Text = "구분";
            // 
            // tb_search
            // 
            this.tb_search.Location = new System.Drawing.Point(210, 14);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(245, 25);
            this.tb_search.TabIndex = 1;
            // 
            // btn_m_search
            // 
            this.btn_m_search.Location = new System.Drawing.Point(467, 14);
            this.btn_m_search.Name = "btn_m_search";
            this.btn_m_search.Size = new System.Drawing.Size(55, 25);
            this.btn_m_search.TabIndex = 2;
            this.btn_m_search.Text = "조회";
            this.btn_m_search.UseVisualStyleBackColor = true;
            this.btn_m_search.Click += new System.EventHandler(this.btn_m_search_Click);
            // 
            // cb_section
            // 
            this.cb_section.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_section.FormattingEnabled = true;
            this.cb_section.Items.AddRange(new object[] {
            "사원번호",
            "이름",
            "부서"});
            this.cb_section.Location = new System.Drawing.Point(74, 16);
            this.cb_section.Name = "cb_section";
            this.cb_section.Size = new System.Drawing.Size(121, 23);
            this.cb_section.TabIndex = 3;
            this.cb_section.SelectedIndexChanged += new System.EventHandler(this.cb_section_SelectedIndexChanged);
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.ColumnCount = 6;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 142F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 186F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 177F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.Controls.Add(this.tb_call, 5, 1);
            this.tableLayoutPanel.Controls.Add(this.lbl_id, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.lbl_name, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.lbl_position, 2, 0);
            this.tableLayoutPanel.Controls.Add(this.lbl_join_date, 2, 1);
            this.tableLayoutPanel.Controls.Add(this.lbl_birth_date, 2, 2);
            this.tableLayoutPanel.Controls.Add(this.cb_religion, 5, 2);
            this.tableLayoutPanel.Controls.Add(this.lbl_email, 2, 3);
            this.tableLayoutPanel.Controls.Add(this.lbl_depart, 4, 0);
            this.tableLayoutPanel.Controls.Add(this.tb_id, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.tb_name_c, 1, 3);
            this.tableLayoutPanel.Controls.Add(this.lbl_call, 4, 1);
            this.tableLayoutPanel.Controls.Add(this.tb_name_k, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.cb_depart, 5, 0);
            this.tableLayoutPanel.Controls.Add(this.lbl_marriage, 4, 3);
            this.tableLayoutPanel.Controls.Add(this.tb_name_e, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.lbl_religion, 4, 2);
            this.tableLayoutPanel.Controls.Add(this.cb_position, 3, 0);
            this.tableLayoutPanel.Controls.Add(this.tb_email, 3, 3);
            this.tableLayoutPanel.Controls.Add(this.dtp_birth_date, 3, 2);
            this.tableLayoutPanel.Controls.Add(this.dtp_join_date, 3, 1);
            this.tableLayoutPanel.Controls.Add(this.groupBox1, 5, 3);
            this.tableLayoutPanel.Location = new System.Drawing.Point(22, 57);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 4;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(777, 119);
            this.tableLayoutPanel.TabIndex = 4;
            // 
            // tb_call
            // 
            this.tb_call.Location = new System.Drawing.Point(603, 31);
            this.tb_call.Name = "tb_call";
            this.tb_call.Size = new System.Drawing.Size(171, 25);
            this.tb_call.TabIndex = 6;
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Location = new System.Drawing.Point(3, 0);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_id.Size = new System.Drawing.Size(67, 27);
            this.lbl_id.TabIndex = 15;
            this.lbl_id.Text = "사원번호";
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(3, 28);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_name.Size = new System.Drawing.Size(37, 27);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "이름";
            // 
            // lbl_position
            // 
            this.lbl_position.AutoSize = true;
            this.lbl_position.Location = new System.Drawing.Point(228, 0);
            this.lbl_position.Name = "lbl_position";
            this.lbl_position.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_position.Size = new System.Drawing.Size(37, 27);
            this.lbl_position.TabIndex = 2;
            this.lbl_position.Text = "직책";
            // 
            // lbl_join_date
            // 
            this.lbl_join_date.AutoSize = true;
            this.lbl_join_date.Location = new System.Drawing.Point(228, 28);
            this.lbl_join_date.Name = "lbl_join_date";
            this.lbl_join_date.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_join_date.Size = new System.Drawing.Size(52, 27);
            this.lbl_join_date.TabIndex = 3;
            this.lbl_join_date.Text = "입사일";
            // 
            // lbl_birth_date
            // 
            this.lbl_birth_date.AutoSize = true;
            this.lbl_birth_date.Location = new System.Drawing.Point(228, 58);
            this.lbl_birth_date.Name = "lbl_birth_date";
            this.lbl_birth_date.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_birth_date.Size = new System.Drawing.Size(67, 27);
            this.lbl_birth_date.TabIndex = 4;
            this.lbl_birth_date.Text = "생년월일";
            // 
            // cb_religion
            // 
            this.cb_religion.CausesValidation = false;
            this.cb_religion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_religion.FormattingEnabled = true;
            this.cb_religion.Location = new System.Drawing.Point(603, 61);
            this.cb_religion.Name = "cb_religion";
            this.cb_religion.Size = new System.Drawing.Size(171, 23);
            this.cb_religion.TabIndex = 31;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(228, 89);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_email.Size = new System.Drawing.Size(52, 27);
            this.lbl_email.TabIndex = 5;
            this.lbl_email.Text = "이메일";
            // 
            // lbl_depart
            // 
            this.lbl_depart.AutoSize = true;
            this.lbl_depart.Location = new System.Drawing.Point(510, 0);
            this.lbl_depart.Name = "lbl_depart";
            this.lbl_depart.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_depart.Size = new System.Drawing.Size(67, 27);
            this.lbl_depart.TabIndex = 6;
            this.lbl_depart.Text = "근무부서";
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(86, 3);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(136, 25);
            this.tb_id.TabIndex = 6;
            // 
            // tb_name_c
            // 
            this.tb_name_c.Location = new System.Drawing.Point(86, 92);
            this.tb_name_c.Name = "tb_name_c";
            this.tb_name_c.Size = new System.Drawing.Size(136, 25);
            this.tb_name_c.TabIndex = 19;
            // 
            // lbl_call
            // 
            this.lbl_call.AutoSize = true;
            this.lbl_call.Location = new System.Drawing.Point(510, 28);
            this.lbl_call.Name = "lbl_call";
            this.lbl_call.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_call.Size = new System.Drawing.Size(52, 27);
            this.lbl_call.TabIndex = 7;
            this.lbl_call.Text = "연락처";
            // 
            // tb_name_k
            // 
            this.tb_name_k.Location = new System.Drawing.Point(86, 31);
            this.tb_name_k.Name = "tb_name_k";
            this.tb_name_k.Size = new System.Drawing.Size(136, 25);
            this.tb_name_k.TabIndex = 17;
            // 
            // cb_depart
            // 
            this.cb_depart.CausesValidation = false;
            this.cb_depart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_depart.FormattingEnabled = true;
            this.cb_depart.Location = new System.Drawing.Point(603, 3);
            this.cb_depart.Name = "cb_depart";
            this.cb_depart.Size = new System.Drawing.Size(171, 23);
            this.cb_depart.TabIndex = 29;
            // 
            // lbl_marriage
            // 
            this.lbl_marriage.AutoSize = true;
            this.lbl_marriage.Location = new System.Drawing.Point(510, 89);
            this.lbl_marriage.Name = "lbl_marriage";
            this.lbl_marriage.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_marriage.Size = new System.Drawing.Size(67, 27);
            this.lbl_marriage.TabIndex = 1;
            this.lbl_marriage.Text = "결혼관계";
            // 
            // tb_name_e
            // 
            this.tb_name_e.Location = new System.Drawing.Point(86, 61);
            this.tb_name_e.Name = "tb_name_e";
            this.tb_name_e.Size = new System.Drawing.Size(136, 25);
            this.tb_name_e.TabIndex = 18;
            // 
            // lbl_religion
            // 
            this.lbl_religion.AutoSize = true;
            this.lbl_religion.Location = new System.Drawing.Point(510, 58);
            this.lbl_religion.Name = "lbl_religion";
            this.lbl_religion.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_religion.Size = new System.Drawing.Size(37, 27);
            this.lbl_religion.TabIndex = 16;
            this.lbl_religion.Text = "종교";
            // 
            // cb_position
            // 
            this.cb_position.CausesValidation = false;
            this.cb_position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_position.FormattingEnabled = true;
            this.cb_position.Location = new System.Drawing.Point(324, 3);
            this.cb_position.Name = "cb_position";
            this.cb_position.Size = new System.Drawing.Size(180, 23);
            this.cb_position.TabIndex = 27;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(324, 92);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(180, 25);
            this.tb_email.TabIndex = 22;
            // 
            // dtp_birth_date
            // 
            this.dtp_birth_date.Location = new System.Drawing.Point(324, 61);
            this.dtp_birth_date.Name = "dtp_birth_date";
            this.dtp_birth_date.Size = new System.Drawing.Size(180, 25);
            this.dtp_birth_date.TabIndex = 38;
            // 
            // dtp_join_date
            // 
            this.dtp_join_date.Location = new System.Drawing.Point(324, 31);
            this.dtp_join_date.Name = "dtp_join_date";
            this.dtp_join_date.Size = new System.Drawing.Size(180, 25);
            this.dtp_join_date.TabIndex = 39;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb_unmarried);
            this.groupBox1.Controls.Add(this.rb_married);
            this.groupBox1.Location = new System.Drawing.Point(603, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 24);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            // 
            // rb_unmarried
            // 
            this.rb_unmarried.AutoSize = true;
            this.rb_unmarried.Location = new System.Drawing.Point(88, 6);
            this.rb_unmarried.Name = "rb_unmarried";
            this.rb_unmarried.Size = new System.Drawing.Size(58, 19);
            this.rb_unmarried.TabIndex = 35;
            this.rb_unmarried.TabStop = true;
            this.rb_unmarried.Text = "미혼";
            this.rb_unmarried.UseVisualStyleBackColor = true;
            // 
            // rb_married
            // 
            this.rb_married.AutoSize = true;
            this.rb_married.Checked = true;
            this.rb_married.Location = new System.Drawing.Point(7, 6);
            this.rb_married.Name = "rb_married";
            this.rb_married.Size = new System.Drawing.Size(58, 19);
            this.rb_married.TabIndex = 34;
            this.rb_married.TabStop = true;
            this.rb_married.Text = "기혼";
            this.rb_married.UseVisualStyleBackColor = true;
            // 
            // lbl_sex
            // 
            this.lbl_sex.AutoSize = true;
            this.lbl_sex.Location = new System.Drawing.Point(510, 0);
            this.lbl_sex.Name = "lbl_sex";
            this.lbl_sex.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_sex.Size = new System.Drawing.Size(37, 27);
            this.lbl_sex.TabIndex = 8;
            this.lbl_sex.Text = "성별";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.label10.Size = new System.Drawing.Size(37, 27);
            this.label10.TabIndex = 9;
            this.label10.Text = "주소";
            // 
            // lbl_sight
            // 
            this.lbl_sight.AutoSize = true;
            this.lbl_sight.Location = new System.Drawing.Point(227, 0);
            this.lbl_sight.Name = "lbl_sight";
            this.lbl_sight.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_sight.Size = new System.Drawing.Size(37, 27);
            this.lbl_sight.TabIndex = 13;
            this.lbl_sight.Text = "시력";
            // 
            // tb_height
            // 
            this.tb_height.Location = new System.Drawing.Point(86, 3);
            this.tb_height.Name = "tb_height";
            this.tb_height.Size = new System.Drawing.Size(135, 25);
            this.tb_height.TabIndex = 23;
            // 
            // tb_sight_l
            // 
            this.tb_sight_l.Location = new System.Drawing.Point(3, 3);
            this.tb_sight_l.Name = "tb_sight_l";
            this.tb_sight_l.Size = new System.Drawing.Size(83, 25);
            this.tb_sight_l.TabIndex = 25;
            // 
            // lvMember
            // 
            this.lvMember.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_id,
            this.col_name,
            this.col_sex,
            this.col_position,
            this.col_depart,
            this.col_email});
            this.lvMember.GridLines = true;
            this.lvMember.Location = new System.Drawing.Point(22, 292);
            this.lvMember.Name = "lvMember";
            this.lvMember.Size = new System.Drawing.Size(777, 200);
            this.lvMember.TabIndex = 5;
            this.lvMember.UseCompatibleStateImageBehavior = false;
            this.lvMember.View = System.Windows.Forms.View.Details;
            this.lvMember.SelectedIndexChanged += new System.EventHandler(this.lvMember_SelectedIndexChanged);
            // 
            // col_id
            // 
            this.col_id.Text = "사원번호";
            this.col_id.Width = 120;
            // 
            // col_name
            // 
            this.col_name.Text = "이름";
            this.col_name.Width = 100;
            // 
            // col_sex
            // 
            this.col_sex.Text = "성별";
            // 
            // col_position
            // 
            this.col_position.Text = "직책";
            this.col_position.Width = 80;
            // 
            // col_depart
            // 
            this.col_depart.Text = "근무부서";
            this.col_depart.Width = 100;
            // 
            // col_email
            // 
            this.col_email.Text = "이메일";
            this.col_email.Width = 310;
            // 
            // tb_address
            // 
            this.tb_address.Location = new System.Drawing.Point(85, 3);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(688, 25);
            this.tb_address.TabIndex = 26;
            // 
            // rb_male
            // 
            this.rb_male.AutoSize = true;
            this.rb_male.Checked = true;
            this.rb_male.Location = new System.Drawing.Point(8, 6);
            this.rb_male.Name = "rb_male";
            this.rb_male.Size = new System.Drawing.Size(43, 19);
            this.rb_male.TabIndex = 32;
            this.rb_male.TabStop = true;
            this.rb_male.Text = "남";
            this.rb_male.UseVisualStyleBackColor = true;
            // 
            // rb_female
            // 
            this.rb_female.AutoSize = true;
            this.rb_female.Location = new System.Drawing.Point(89, 5);
            this.rb_female.Name = "rb_female";
            this.rb_female.Size = new System.Drawing.Size(43, 19);
            this.rb_female.TabIndex = 33;
            this.rb_female.Text = "여";
            this.rb_female.UseVisualStyleBackColor = true;
            // 
            // cb_blood
            // 
            this.cb_blood.CausesValidation = false;
            this.cb_blood.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_blood.FormattingEnabled = true;
            this.cb_blood.Items.AddRange(new object[] {
            "A",
            "B",
            "AB",
            "O"});
            this.cb_blood.Location = new System.Drawing.Point(326, 38);
            this.cb_blood.Name = "cb_blood";
            this.cb_blood.Size = new System.Drawing.Size(178, 23);
            this.cb_blood.TabIndex = 28;
            // 
            // tb_weight
            // 
            this.tb_weight.Location = new System.Drawing.Point(86, 38);
            this.tb_weight.Name = "tb_weight";
            this.tb_weight.Size = new System.Drawing.Size(135, 25);
            this.tb_weight.TabIndex = 24;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(227, 35);
            this.label15.Name = "label15";
            this.label15.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.label15.Size = new System.Drawing.Size(52, 27);
            this.label15.TabIndex = 14;
            this.label15.Text = "혈액형";
            // 
            // lbl_weight
            // 
            this.lbl_weight.AutoSize = true;
            this.lbl_weight.Location = new System.Drawing.Point(3, 35);
            this.lbl_weight.Name = "lbl_weight";
            this.lbl_weight.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_weight.Size = new System.Drawing.Size(37, 27);
            this.lbl_weight.TabIndex = 12;
            this.lbl_weight.Text = "체중";
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.Location = new System.Drawing.Point(3, 0);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbl_height.Size = new System.Drawing.Size(22, 27);
            this.lbl_height.TabIndex = 11;
            this.lbl_height.Text = "키";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.68211F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 89.31789F));
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tb_address, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(22, 174);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(777, 40);
            this.tableLayoutPanel3.TabIndex = 32;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 141F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 184F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 92F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 178F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.lbl_height, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.lbl_weight, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tb_height, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.tb_weight, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.lbl_sight, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label15, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.cb_blood, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.lbl_sex, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.groupBox2, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel1, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.s_id, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this.hidden_s, 4, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(22, 207);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.17391F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.82609F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(777, 69);
            this.tableLayoutPanel4.TabIndex = 33;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rb_female);
            this.groupBox2.Controls.Add(this.rb_male);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox2.Location = new System.Drawing.Point(602, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(172, 29);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tb_sight_l, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_sight_r, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(326, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(178, 28);
            this.tableLayoutPanel1.TabIndex = 30;
            // 
            // tb_sight_r
            // 
            this.tb_sight_r.Location = new System.Drawing.Point(92, 3);
            this.tb_sight_r.Name = "tb_sight_r";
            this.tb_sight_r.Size = new System.Drawing.Size(83, 25);
            this.tb_sight_r.TabIndex = 26;
            // 
            // s_id
            // 
            this.s_id.Location = new System.Drawing.Point(602, 38);
            this.s_id.Name = "s_id";
            this.s_id.Size = new System.Drawing.Size(100, 25);
            this.s_id.TabIndex = 31;
            this.s_id.Visible = false;
            // 
            // hidden_s
            // 
            this.hidden_s.Location = new System.Drawing.Point(510, 38);
            this.hidden_s.Name = "hidden_s";
            this.hidden_s.Size = new System.Drawing.Size(86, 25);
            this.hidden_s.TabIndex = 32;
            this.hidden_s.Visible = false;
            // 
            // btn_m_insert
            // 
            this.btn_m_insert.Location = new System.Drawing.Point(632, 16);
            this.btn_m_insert.Name = "btn_m_insert";
            this.btn_m_insert.Size = new System.Drawing.Size(52, 23);
            this.btn_m_insert.TabIndex = 35;
            this.btn_m_insert.Text = "입력";
            this.btn_m_insert.UseVisualStyleBackColor = true;
            this.btn_m_insert.Click += new System.EventHandler(this.btn_m_insert_Click);
            // 
            // btn_m_update
            // 
            this.btn_m_update.Location = new System.Drawing.Point(690, 16);
            this.btn_m_update.Name = "btn_m_update";
            this.btn_m_update.Size = new System.Drawing.Size(52, 23);
            this.btn_m_update.TabIndex = 36;
            this.btn_m_update.Text = "수정";
            this.btn_m_update.UseVisualStyleBackColor = true;
            this.btn_m_update.Click += new System.EventHandler(this.btn_m_update_Click);
            // 
            // btn_m_delete
            // 
            this.btn_m_delete.Location = new System.Drawing.Point(747, 16);
            this.btn_m_delete.Name = "btn_m_delete";
            this.btn_m_delete.Size = new System.Drawing.Size(52, 23);
            this.btn_m_delete.TabIndex = 37;
            this.btn_m_delete.Text = "삭제";
            this.btn_m_delete.UseVisualStyleBackColor = true;
            this.btn_m_delete.Click += new System.EventHandler(this.btn_m_delete_Click);
            // 
            // Member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 507);
            this.Controls.Add(this.btn_m_delete);
            this.Controls.Add(this.btn_m_update);
            this.Controls.Add(this.btn_m_insert);
            this.Controls.Add(this.tableLayoutPanel4);
            this.Controls.Add(this.lvMember);
            this.Controls.Add(this.tableLayoutPanel);
            this.Controls.Add(this.cb_section);
            this.Controls.Add(this.btn_m_search);
            this.Controls.Add(this.tb_search);
            this.Controls.Add(this.lbl_section);
            this.Controls.Add(this.tableLayoutPanel3);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Member";
            this.Text = "사원 관리";
            this.Load += new System.EventHandler(this.Member_Load);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_section;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Button btn_m_search;
        private System.Windows.Forms.ComboBox cb_section;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.ListView lvMember;
        private System.Windows.Forms.Label lbl_position;
        private System.Windows.Forms.Label lbl_join_date;
        private System.Windows.Forms.Label lbl_birth_date;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_depart;
        private System.Windows.Forms.Label lbl_call;
        private System.Windows.Forms.Label lbl_sex;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_sight;
        private System.Windows.Forms.Label lbl_marriage;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.TextBox tb_name_k;
        private System.Windows.Forms.TextBox tb_name_e;
        private System.Windows.Forms.TextBox tb_name_c;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.TextBox tb_height;
        private System.Windows.Forms.TextBox tb_sight_l;
        private System.Windows.Forms.TextBox tb_call;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.ComboBox cb_position;
        private System.Windows.Forms.ComboBox cb_depart;
        private System.Windows.Forms.RadioButton rb_male;
        private System.Windows.Forms.RadioButton rb_female;
        private System.Windows.Forms.ColumnHeader col_id;
        private System.Windows.Forms.ColumnHeader col_name;
        private System.Windows.Forms.ColumnHeader col_sex;
        private System.Windows.Forms.ColumnHeader col_position;
        private System.Windows.Forms.ColumnHeader col_depart;
        private System.Windows.Forms.ColumnHeader col_email;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tb_weight;
        private System.Windows.Forms.ComboBox cb_blood;
        private System.Windows.Forms.Label lbl_religion;
        private System.Windows.Forms.ComboBox cb_religion;
        private System.Windows.Forms.Label lbl_weight;
        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.DateTimePicker dtp_birth_date;
        private System.Windows.Forms.DateTimePicker dtp_join_date;
        private System.Windows.Forms.Button btn_m_insert;
        private System.Windows.Forms.Button btn_m_update;
        private System.Windows.Forms.Button btn_m_delete;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb_unmarried;
        private System.Windows.Forms.RadioButton rb_married;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tb_sight_r;
        private System.Windows.Forms.TextBox s_id;
        private System.Windows.Forms.TextBox hidden_s;
    }
}