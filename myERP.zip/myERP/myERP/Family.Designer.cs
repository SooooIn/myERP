﻿namespace myERP
{
    partial class Family
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_f_id = new System.Windows.Forms.Label();
            this.btn_f_search = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tb_f_id2 = new System.Windows.Forms.TextBox();
            this.lbl_f_id2 = new System.Windows.Forms.Label();
            this.lbl_f_name = new System.Windows.Forms.Label();
            this.lbl_f_depart = new System.Windows.Forms.Label();
            this.lbl_f_position = new System.Windows.Forms.Label();
            this.tb_f_name = new System.Windows.Forms.TextBox();
            this.tb_f_depart = new System.Windows.Forms.TextBox();
            this.tb_f_position = new System.Windows.Forms.TextBox();
            this.lvFamily = new System.Windows.Forms.ListView();
            this.lvFamily_r = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvFamily_n = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvFamily_b = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvFamily_j = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvFamily_p = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvFamily_c = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.no = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tb_f_relation = new System.Windows.Forms.TextBox();
            this.lbl_f_relation = new System.Windows.Forms.Label();
            this.lbl_f_place = new System.Windows.Forms.Label();
            this.lbl_f_name2 = new System.Windows.Forms.Label();
            this.lbl_f_job = new System.Windows.Forms.Label();
            this.lbl_f_birth = new System.Windows.Forms.Label();
            this.lbl_f_number = new System.Windows.Forms.Label();
            this.tb_f_name2 = new System.Windows.Forms.TextBox();
            this.tb_f_place = new System.Windows.Forms.TextBox();
            this.tb_f_job = new System.Windows.Forms.TextBox();
            this.tb_f_number = new System.Windows.Forms.TextBox();
            this.dtp_f_birth = new System.Windows.Forms.DateTimePicker();
            this.btn_f_insert = new System.Windows.Forms.Button();
            this.btn_f_update = new System.Windows.Forms.Button();
            this.btn_f_delete = new System.Windows.Forms.Button();
            this.cb_f_id = new System.Windows.Forms.ComboBox();
            this.call_hidden = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_f_id
            // 
            this.lbl_f_id.AutoSize = true;
            this.lbl_f_id.Location = new System.Drawing.Point(13, 16);
            this.lbl_f_id.Name = "lbl_f_id";
            this.lbl_f_id.Size = new System.Drawing.Size(67, 15);
            this.lbl_f_id.TabIndex = 0;
            this.lbl_f_id.Text = "사원번호";
            // 
            // btn_f_search
            // 
            this.btn_f_search.Location = new System.Drawing.Point(272, 13);
            this.btn_f_search.Name = "btn_f_search";
            this.btn_f_search.Size = new System.Drawing.Size(49, 25);
            this.btn_f_search.TabIndex = 2;
            this.btn_f_search.Text = "조회";
            this.btn_f_search.UseVisualStyleBackColor = true;
            this.btn_f_search.Click += new System.EventHandler(this.btn_f_search_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 87F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 127F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 78F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 115F));
            this.tableLayoutPanel1.Controls.Add(this.tb_f_id2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_f_id2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_f_name, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_f_depart, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_f_position, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_f_name, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_f_depart, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.tb_f_position, 7, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 54);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(776, 30);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // tb_f_id2
            // 
            this.tb_f_id2.Enabled = false;
            this.tb_f_id2.Location = new System.Drawing.Point(85, 3);
            this.tb_f_id2.Name = "tb_f_id2";
            this.tb_f_id2.Size = new System.Drawing.Size(118, 25);
            this.tb_f_id2.TabIndex = 8;
            // 
            // lbl_f_id2
            // 
            this.lbl_f_id2.AutoSize = true;
            this.lbl_f_id2.Location = new System.Drawing.Point(3, 0);
            this.lbl_f_id2.Name = "lbl_f_id2";
            this.lbl_f_id2.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_id2.Size = new System.Drawing.Size(67, 29);
            this.lbl_f_id2.TabIndex = 8;
            this.lbl_f_id2.Text = "사원번호";
            // 
            // lbl_f_name
            // 
            this.lbl_f_name.AutoSize = true;
            this.lbl_f_name.Location = new System.Drawing.Point(209, 0);
            this.lbl_f_name.Name = "lbl_f_name";
            this.lbl_f_name.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_name.Size = new System.Drawing.Size(37, 29);
            this.lbl_f_name.TabIndex = 9;
            this.lbl_f_name.Text = "성명";
            // 
            // lbl_f_depart
            // 
            this.lbl_f_depart.AutoSize = true;
            this.lbl_f_depart.Location = new System.Drawing.Point(423, 0);
            this.lbl_f_depart.Name = "lbl_f_depart";
            this.lbl_f_depart.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_depart.Size = new System.Drawing.Size(37, 29);
            this.lbl_f_depart.TabIndex = 10;
            this.lbl_f_depart.Text = "부서";
            // 
            // lbl_f_position
            // 
            this.lbl_f_position.AutoSize = true;
            this.lbl_f_position.Location = new System.Drawing.Point(608, 0);
            this.lbl_f_position.Name = "lbl_f_position";
            this.lbl_f_position.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_position.Size = new System.Drawing.Size(37, 29);
            this.lbl_f_position.TabIndex = 11;
            this.lbl_f_position.Text = "직책";
            // 
            // tb_f_name
            // 
            this.tb_f_name.Enabled = false;
            this.tb_f_name.Location = new System.Drawing.Point(296, 3);
            this.tb_f_name.Name = "tb_f_name";
            this.tb_f_name.Size = new System.Drawing.Size(121, 25);
            this.tb_f_name.TabIndex = 12;
            // 
            // tb_f_depart
            // 
            this.tb_f_depart.Enabled = false;
            this.tb_f_depart.Location = new System.Drawing.Point(501, 3);
            this.tb_f_depart.Name = "tb_f_depart";
            this.tb_f_depart.Size = new System.Drawing.Size(101, 25);
            this.tb_f_depart.TabIndex = 13;
            // 
            // tb_f_position
            // 
            this.tb_f_position.Enabled = false;
            this.tb_f_position.Location = new System.Drawing.Point(664, 3);
            this.tb_f_position.Name = "tb_f_position";
            this.tb_f_position.Size = new System.Drawing.Size(109, 25);
            this.tb_f_position.TabIndex = 14;
            // 
            // lvFamily
            // 
            this.lvFamily.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvFamily_r,
            this.lvFamily_n,
            this.lvFamily_b,
            this.lvFamily_j,
            this.lvFamily_p,
            this.lvFamily_c,
            this.no});
            this.lvFamily.GridLines = true;
            this.lvFamily.Location = new System.Drawing.Point(12, 226);
            this.lvFamily.Name = "lvFamily";
            this.lvFamily.Size = new System.Drawing.Size(776, 218);
            this.lvFamily.TabIndex = 0;
            this.lvFamily.UseCompatibleStateImageBehavior = false;
            this.lvFamily.View = System.Windows.Forms.View.Details;
            this.lvFamily.SelectedIndexChanged += new System.EventHandler(this.lvFamily_SelectedIndexChanged);
            // 
            // lvFamily_r
            // 
            this.lvFamily_r.Text = "관계";
            this.lvFamily_r.Width = 80;
            // 
            // lvFamily_n
            // 
            this.lvFamily_n.Text = "성명";
            this.lvFamily_n.Width = 100;
            // 
            // lvFamily_b
            // 
            this.lvFamily_b.Text = "생년월일";
            this.lvFamily_b.Width = 120;
            // 
            // lvFamily_j
            // 
            this.lvFamily_j.Text = "직업";
            this.lvFamily_j.Width = 120;
            // 
            // lvFamily_p
            // 
            this.lvFamily_p.Text = "근무처";
            this.lvFamily_p.Width = 120;
            // 
            // lvFamily_c
            // 
            this.lvFamily_c.Text = "연락처";
            this.lvFamily_c.Width = 120;
            // 
            // no
            // 
            this.no.Text = "";
            this.no.Width = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 6;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 154F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 164F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 92F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel2.Controls.Add(this.tb_f_relation, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_f_relation, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_f_place, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_f_name2, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_f_job, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_f_birth, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_f_number, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.tb_f_name2, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.tb_f_place, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.tb_f_job, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.tb_f_number, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.dtp_f_birth, 5, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 116);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(776, 60);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // tb_f_relation
            // 
            this.tb_f_relation.Location = new System.Drawing.Point(103, 3);
            this.tb_f_relation.Name = "tb_f_relation";
            this.tb_f_relation.Size = new System.Drawing.Size(148, 25);
            this.tb_f_relation.TabIndex = 8;
            // 
            // lbl_f_relation
            // 
            this.lbl_f_relation.AutoSize = true;
            this.lbl_f_relation.Location = new System.Drawing.Point(3, 0);
            this.lbl_f_relation.Name = "lbl_f_relation";
            this.lbl_f_relation.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_relation.Size = new System.Drawing.Size(37, 29);
            this.lbl_f_relation.TabIndex = 12;
            this.lbl_f_relation.Text = "관계";
            // 
            // lbl_f_place
            // 
            this.lbl_f_place.AutoSize = true;
            this.lbl_f_place.Location = new System.Drawing.Point(3, 31);
            this.lbl_f_place.Name = "lbl_f_place";
            this.lbl_f_place.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_place.Size = new System.Drawing.Size(52, 29);
            this.lbl_f_place.TabIndex = 13;
            this.lbl_f_place.Text = "근무처";
            // 
            // lbl_f_name2
            // 
            this.lbl_f_name2.AutoSize = true;
            this.lbl_f_name2.Location = new System.Drawing.Point(257, 0);
            this.lbl_f_name2.Name = "lbl_f_name2";
            this.lbl_f_name2.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_name2.Size = new System.Drawing.Size(37, 29);
            this.lbl_f_name2.TabIndex = 14;
            this.lbl_f_name2.Text = "성명";
            // 
            // lbl_f_job
            // 
            this.lbl_f_job.AutoSize = true;
            this.lbl_f_job.Location = new System.Drawing.Point(257, 31);
            this.lbl_f_job.Name = "lbl_f_job";
            this.lbl_f_job.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_job.Size = new System.Drawing.Size(37, 29);
            this.lbl_f_job.TabIndex = 15;
            this.lbl_f_job.Text = "직업";
            // 
            // lbl_f_birth
            // 
            this.lbl_f_birth.AutoSize = true;
            this.lbl_f_birth.Location = new System.Drawing.Point(527, 0);
            this.lbl_f_birth.Name = "lbl_f_birth";
            this.lbl_f_birth.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_birth.Size = new System.Drawing.Size(67, 29);
            this.lbl_f_birth.TabIndex = 16;
            this.lbl_f_birth.Text = "생년월일";
            // 
            // lbl_f_number
            // 
            this.lbl_f_number.AutoSize = true;
            this.lbl_f_number.Location = new System.Drawing.Point(527, 31);
            this.lbl_f_number.Name = "lbl_f_number";
            this.lbl_f_number.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.lbl_f_number.Size = new System.Drawing.Size(52, 29);
            this.lbl_f_number.TabIndex = 17;
            this.lbl_f_number.Text = "연락처";
            // 
            // tb_f_name2
            // 
            this.tb_f_name2.Location = new System.Drawing.Point(363, 3);
            this.tb_f_name2.Name = "tb_f_name2";
            this.tb_f_name2.Size = new System.Drawing.Size(158, 25);
            this.tb_f_name2.TabIndex = 18;
            // 
            // tb_f_place
            // 
            this.tb_f_place.Location = new System.Drawing.Point(103, 34);
            this.tb_f_place.Name = "tb_f_place";
            this.tb_f_place.Size = new System.Drawing.Size(148, 25);
            this.tb_f_place.TabIndex = 20;
            // 
            // tb_f_job
            // 
            this.tb_f_job.Location = new System.Drawing.Point(363, 34);
            this.tb_f_job.Name = "tb_f_job";
            this.tb_f_job.Size = new System.Drawing.Size(158, 25);
            this.tb_f_job.TabIndex = 21;
            // 
            // tb_f_number
            // 
            this.tb_f_number.Location = new System.Drawing.Point(619, 34);
            this.tb_f_number.Name = "tb_f_number";
            this.tb_f_number.Size = new System.Drawing.Size(154, 25);
            this.tb_f_number.TabIndex = 22;
            // 
            // dtp_f_birth
            // 
            this.dtp_f_birth.Location = new System.Drawing.Point(619, 3);
            this.dtp_f_birth.Name = "dtp_f_birth";
            this.dtp_f_birth.Size = new System.Drawing.Size(154, 25);
            this.dtp_f_birth.TabIndex = 23;
            // 
            // btn_f_insert
            // 
            this.btn_f_insert.Location = new System.Drawing.Point(611, 194);
            this.btn_f_insert.Name = "btn_f_insert";
            this.btn_f_insert.Size = new System.Drawing.Size(55, 23);
            this.btn_f_insert.TabIndex = 5;
            this.btn_f_insert.Text = "입력";
            this.btn_f_insert.UseVisualStyleBackColor = true;
            this.btn_f_insert.Click += new System.EventHandler(this.btn_f_insert_Click);
            // 
            // btn_f_update
            // 
            this.btn_f_update.Location = new System.Drawing.Point(672, 194);
            this.btn_f_update.Name = "btn_f_update";
            this.btn_f_update.Size = new System.Drawing.Size(55, 23);
            this.btn_f_update.TabIndex = 6;
            this.btn_f_update.Text = "수정";
            this.btn_f_update.UseVisualStyleBackColor = true;
            this.btn_f_update.Click += new System.EventHandler(this.btn_f_update_Click);
            // 
            // btn_f_delete
            // 
            this.btn_f_delete.Location = new System.Drawing.Point(733, 194);
            this.btn_f_delete.Name = "btn_f_delete";
            this.btn_f_delete.Size = new System.Drawing.Size(55, 23);
            this.btn_f_delete.TabIndex = 7;
            this.btn_f_delete.Text = "삭제";
            this.btn_f_delete.UseVisualStyleBackColor = true;
            this.btn_f_delete.Click += new System.EventHandler(this.btn_f_delete_Click);
            // 
            // cb_f_id
            // 
            this.cb_f_id.FormattingEnabled = true;
            this.cb_f_id.Location = new System.Drawing.Point(87, 13);
            this.cb_f_id.Name = "cb_f_id";
            this.cb_f_id.Size = new System.Drawing.Size(171, 23);
            this.cb_f_id.TabIndex = 8;
            // 
            // call_hidden
            // 
            this.call_hidden.Location = new System.Drawing.Point(631, 87);
            this.call_hidden.Name = "call_hidden";
            this.call_hidden.Size = new System.Drawing.Size(100, 25);
            this.call_hidden.TabIndex = 9;
            this.call_hidden.Visible = false;
            // 
            // Family
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 456);
            this.Controls.Add(this.call_hidden);
            this.Controls.Add(this.cb_f_id);
            this.Controls.Add(this.btn_f_delete);
            this.Controls.Add(this.btn_f_update);
            this.Controls.Add(this.btn_f_insert);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.lvFamily);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.btn_f_search);
            this.Controls.Add(this.lbl_f_id);
            this.Name = "Family";
            this.Text = "가족 사항 관리";
            this.Load += new System.EventHandler(this.Family_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_f_id;
        private System.Windows.Forms.Button btn_f_search;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ListView lvFamily;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn_f_insert;
        private System.Windows.Forms.Label lbl_f_id2;
        private System.Windows.Forms.Label lbl_f_name;
        private System.Windows.Forms.Label lbl_f_depart;
        private System.Windows.Forms.Label lbl_f_position;
        private System.Windows.Forms.Label lbl_f_relation;
        private System.Windows.Forms.Label lbl_f_place;
        private System.Windows.Forms.Label lbl_f_name2;
        private System.Windows.Forms.Label lbl_f_job;
        private System.Windows.Forms.Label lbl_f_birth;
        private System.Windows.Forms.Label lbl_f_number;
        private System.Windows.Forms.Button btn_f_update;
        private System.Windows.Forms.Button btn_f_delete;
        private System.Windows.Forms.TextBox tb_f_id2;
        private System.Windows.Forms.TextBox tb_f_name;
        private System.Windows.Forms.TextBox tb_f_depart;
        private System.Windows.Forms.TextBox tb_f_position;
        private System.Windows.Forms.ColumnHeader lvFamily_r;
        private System.Windows.Forms.ColumnHeader lvFamily_n;
        private System.Windows.Forms.ColumnHeader lvFamily_b;
        private System.Windows.Forms.ColumnHeader lvFamily_j;
        private System.Windows.Forms.ColumnHeader lvFamily_p;
        private System.Windows.Forms.ColumnHeader lvFamily_c;
        private System.Windows.Forms.TextBox tb_f_relation;
        private System.Windows.Forms.TextBox tb_f_name2;
        private System.Windows.Forms.TextBox tb_f_place;
        private System.Windows.Forms.TextBox tb_f_job;
        private System.Windows.Forms.TextBox tb_f_number;
        private System.Windows.Forms.ComboBox cb_f_id;
        private System.Windows.Forms.DateTimePicker dtp_f_birth;
        private System.Windows.Forms.ColumnHeader no;
        private System.Windows.Forms.TextBox call_hidden;
    }
}