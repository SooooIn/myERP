﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myERP
{
    public partial class Religion : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Religion()
        {
            InitializeComponent();

            lvReligion_s.View = View.Details;
            lvReligion_s.Items.Clear();

            string Sval, Scode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from religion order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Sval = reader["val"].ToString();
                        Scode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Sval;
                        item.SubItems.Add(Scode);

                        this.lvReligion_s.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_r_search_Click(object sender, EventArgs e)
        {
            lvReligion_s.View = View.Details;
            lvReligion_s.Items.Clear();

            string SearchValue = s_religion.ToString();
            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from religion where val='" + s_religion.Text + "' order by val";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvReligion_s.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            s_religion.Text = "";
        }

        private void r_tabMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            lvReligion_s.View = View.Details;
            lvReligion_a.View = View.Details;
            lvReligion_u.View = View.Details;
            lvReligion_d.View = View.Details;

            lvReligion_s.Items.Clear();
            lvReligion_a.Items.Clear();
            lvReligion_u.Items.Clear();
            lvReligion_d.Items.Clear();

            string Sval, Scode, Aval, Acode, Uval, Ucode, Dval, Dcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from religion order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Sval = reader["val"].ToString();
                        Scode = reader["code"].ToString();
                        Aval = reader["val"].ToString();
                        Acode = reader["code"].ToString();
                        Uval = reader["val"].ToString();
                        Ucode = reader["code"].ToString();
                        Dval = reader["val"].ToString();
                        Dcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();
                        ListViewItem item1 = new ListViewItem();
                        ListViewItem item2 = new ListViewItem();
                        ListViewItem item3 = new ListViewItem();

                        item.Text = Sval;
                        item.SubItems.Add(Scode);
                        item1.Text = Aval;
                        item1.SubItems.Add(Acode);
                        item2.Text = Uval;
                        item2.SubItems.Add(Ucode);
                        item3.Text = Dval;
                        item3.SubItems.Add(Dcode);

                        this.lvReligion_s.Items.Add(item);
                        this.lvReligion_a.Items.Add(item1);
                        this.lvReligion_u.Items.Add(item2);
                        this.lvReligion_d.Items.Add(item3);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_r_add_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "insert into religion " + "values('" + a_religion.Text + "', '" + a_r_code.Text + "')";
            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            //데이터 새로고침
            lvReligion_a.View = View.Details;
            lvReligion_a.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from religion order by val asc";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    { 
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvReligion_a.Items.Add(item);

                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            a_religion.Text = "";
            a_r_code.Text = "";
        }

        private void lvReligion_u_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvReligion_u.SelectedItems.Count != 0)
            {
                int SelectRow = lvReligion_u.SelectedItems[0].Index;

                u_religion.Text = lvReligion_u.Items[SelectRow].SubItems[0].Text;
                ur_hidden2.Text = lvReligion_u.Items[SelectRow].SubItems[0].Text;
                u_r_code.Text = lvReligion_u.Items[SelectRow].SubItems[1].Text;
                ur_hidden.Text = lvReligion_u.Items[SelectRow].SubItems[1].Text;
            }
        }

        private void btn_r_update_Click(object sender, EventArgs e)
        {
            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var Conn2 = new SqlConnection(Constr);
            Conn2.Open();

            var strSQL1 = "update religion set val='" + u_religion.Text + "', code= '" + u_r_code.Text + "' where code='" + ur_hidden.Text + "'";
            var strSQL2 = "update member set religion='" + u_religion.Text + "' where religion='" + ur_hidden2.Text + "'";

            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom2.ExecuteNonQuery();

            Conn1.Close();
            Conn2.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            //데이터 새로고침
            lvReligion_u.View = View.Details;
            lvReligion_u.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from religion order by val";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvReligion_u.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            u_religion.Text = "";
            u_r_code.Text = "";
        }

        private void lvReligion_d_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvReligion_d.SelectedItems.Count != 0)
            {
                int SelectRow = lvReligion_d.SelectedItems[0].Index;

                dr_hidden2.Text = lvReligion_d.Items[SelectRow].SubItems[0].Text;
                dr_hidden.Text = lvReligion_d.Items[SelectRow].SubItems[1].Text;
            }
        }

        private void btn_r_delete_Click(object sender, EventArgs e)
        {
            int state = 0; // 삭제 가능 상태

            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var strSQL1 = "select religion from member where religion='" + dr_hidden2.Text + "'";
            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();

            SqlDataReader reader1 = myCom1.ExecuteReader();

            while (reader1.Read())
            {
                if (reader1["religion"].ToString() == dr_hidden2.Text)
                {
                    state = 1; // 사용중인 코드로 인한 삭제 불가 상태
                }
            }

            reader1.Close();
            Conn1.Close();

            if(state==0)
            {
                var Conn = new SqlConnection(Constr);
                Conn.Open();

                var strSQL = "delete from religion where code='" + dr_hidden.Text + "'";
                var myCom = new SqlCommand(strSQL, Conn);
                myCom.ExecuteNonQuery();

                Conn.Close();
                MessageBox.Show("데이터가 삭제되었습니다.", "알림");
            }
            else if(state==1)
            {
                MessageBox.Show("사용 중인 코드입니다.", "알림");
            }

            //데이터 새로고침
            lvReligion_d.View = View.Details;
            lvReligion_d.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from religion order by val";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvReligion_d.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }
    }
}
