﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myERP
{
    public partial class Position : Form
    {
        private string Constr = "server=localhost;uid=myERP;pwd=1234;database=myERP";

        public Position()
        {
            InitializeComponent();

            lvPosition_s.View = View.Details;
            lvPosition_s.Items.Clear();

            string Sval, Scode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from position";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Sval = reader["val"].ToString();
                        Scode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Sval;
                        item.SubItems.Add(Scode);

                        this.lvPosition_s.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_p_search_Click(object sender, EventArgs e)
        {
            lvPosition_s.View = View.Details;

            lvPosition_s.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from position where val='" + s_position.Text + "'";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvPosition_s.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            s_position.Text = "";
        }

        private void p_TabMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            lvPosition_s.View = View.Details;
            lvPosition_a.View = View.Details;
            lvPosition_u.View = View.Details;
            lvPosition_d.View = View.Details;

            lvPosition_s.Items.Clear();
            lvPosition_a.Items.Clear();
            lvPosition_u.Items.Clear();
            lvPosition_d.Items.Clear();

            string Sval, Scode, Aval, Acode, Uval, Ucode, Dval, Dcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from position";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Sval = reader["val"].ToString();
                        Scode = reader["code"].ToString();
                        Aval = reader["val"].ToString();
                        Acode = reader["code"].ToString();
                        Uval = reader["val"].ToString();
                        Ucode = reader["code"].ToString();
                        Dval = reader["val"].ToString();
                        Dcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();
                        ListViewItem item1 = new ListViewItem();
                        ListViewItem item2 = new ListViewItem();
                        ListViewItem item3 = new ListViewItem();

                        item.Text = Sval;
                        item.SubItems.Add(Scode);
                        item1.Text = Aval;
                        item1.SubItems.Add(Acode);
                        item2.Text = Uval;
                        item2.SubItems.Add(Ucode);
                        item3.Text = Dval;
                        item3.SubItems.Add(Dcode);

                        this.lvPosition_s.Items.Add(item);
                        this.lvPosition_a.Items.Add(item1);
                        this.lvPosition_u.Items.Add(item2);
                        this.lvPosition_d.Items.Add(item3);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }

        private void btn_p_add_Click(object sender, EventArgs e)
        {
            var Conn = new SqlConnection(Constr);
            Conn.Open();

            var strSQL = "insert into position " + "values('" + a_position.Text + "', '" + a_p_code.Text + "')";
            var myCom = new SqlCommand(strSQL, Conn);
            myCom.ExecuteNonQuery();

            Conn.Close();
            MessageBox.Show("데이터가 저장되었습니다.", "알림");

            //데이터 새로고침
            lvPosition_a.View = View.Details;

            lvPosition_a.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from position";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();
                
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvPosition_a.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            a_position.Text = "";
            a_p_code.Text = "";
        }

        private void lvPosition_u_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvPosition_u.SelectedItems.Count != 0)
            {
                int SelectRow = lvPosition_u.SelectedItems[0].Index;

                u_position.Text = lvPosition_u.Items[SelectRow].SubItems[0].Text;
                up_hidden2.Text = lvPosition_u.Items[SelectRow].SubItems[0].Text;
                u_p_code.Text = lvPosition_u.Items[SelectRow].SubItems[1].Text;
                up_hidden.Text = lvPosition_u.Items[SelectRow].SubItems[1].Text;
            }
        }

        private void btn_p_update_Click(object sender, EventArgs e)
        {
            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var Conn2 = new SqlConnection(Constr);
            Conn2.Open();
            var Conn3 = new SqlConnection(Constr);
            Conn3.Open();

            var strSQL1 = "update position set val='" + u_position.Text + "', code= '" + u_p_code.Text + "' where code='" + up_hidden.Text + "'";
            var strSQL2 = "update member set position='" + u_position.Text + "' where position='" + up_hidden2.Text + "'";
            var strSQL3 = "update retired set position='" + u_position.Text + "' where position='" + up_hidden2.Text + "'";

            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom2.ExecuteNonQuery();
            var myCom3 = new SqlCommand(strSQL3, Conn3);
            myCom3.ExecuteNonQuery();

            Conn1.Close();
            Conn2.Close();
            Conn3.Close();

            //데이터 새로고침
            lvPosition_u.View = View.Details;

            lvPosition_u.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from position";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvPosition_u.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }

            // textbox 초기화
            u_position.Text = "";
            u_p_code.Text = "";
        }

        private void lvPosition_d_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvPosition_d.SelectedItems.Count != 0)
            {
                int SelectRow = lvPosition_d.SelectedItems[0].Index;

                dp_hidden2.Text = lvPosition_d.Items[SelectRow].SubItems[0].Text;
                dp_hidden.Text = lvPosition_d.Items[SelectRow].SubItems[1].Text;
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int state = 0; // 삭제 가능 상태

            var Conn1 = new SqlConnection(Constr);
            Conn1.Open();
            var strSQL1 = "select position from member where position='" + dp_hidden2.Text + "'";
            var myCom1 = new SqlCommand(strSQL1, Conn1);
            myCom1.ExecuteNonQuery();

            SqlDataReader reader1 = myCom1.ExecuteReader();

            while (reader1.Read())
            {
                if (reader1["position"].ToString() == dp_hidden2.Text)
                {
                    state = 1; // 사용중인 코드로 인한 삭제 불가 상태
                }
            }

            reader1.Close();
            Conn1.Close();

            var Conn2 = new SqlConnection(Constr);
            Conn2.Open();
            var strSQL2 = "select position from retired where position='" + dp_hidden2.Text + "'";
            var myCom2 = new SqlCommand(strSQL2, Conn2);
            myCom2.ExecuteNonQuery();

            SqlDataReader reader2 = myCom2.ExecuteReader();

            while (reader2.Read())
            {
                if (reader2["position"].ToString() == dp_hidden2.Text)
                {
                    state = 1; // 사용중인 코드로 인한 삭제 불가 상태
                }
            }

            reader2.Close();
            Conn2.Close();

            if (state == 0)
            {
                var Conn = new SqlConnection(Constr);
                Conn.Open();

                var strSQL = "delete from position where code='" + dp_hidden.Text + "'";
                var myCom = new SqlCommand(strSQL, Conn);
                myCom.ExecuteNonQuery();

                Conn.Close();
                MessageBox.Show("데이터가 삭제되었습니다.", "알림");
            }
            else if(state==1)
            {
                MessageBox.Show("사용 중인 코드입니다.", "알림");
            }

            //데이터 새로고침
            lvPosition_d.View = View.Details;
            lvPosition_d.Items.Clear();

            string Searchval, Searchcode;
            try
            {
                SqlConnection dbcon = new SqlConnection();
                dbcon.ConnectionString = "server=localhost;uid=myERP;pwd=1234;database=myERP";
                String Sql = "Select * from position";
                SqlCommand dbcmd = new SqlCommand(Sql, dbcon);

                dbcon.Open();

                SqlDataReader reader = dbcmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Searchval = reader["val"].ToString();
                        Searchcode = reader["code"].ToString();

                        ListViewItem item = new ListViewItem();

                        item.Text = Searchval;
                        item.SubItems.Add(Searchcode);

                        this.lvPosition_d.Items.Add(item);
                    }
                }
                reader.Close();
                dbcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "오류!");
            }
        }
    }
}
